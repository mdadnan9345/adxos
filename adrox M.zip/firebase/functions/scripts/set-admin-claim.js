#!/usr/bin/env node
/**
 * One-time local Admin provisioning for adnify-f033d.
 *
 * This script never stores or asks for the user's password. It uses only a
 * Firebase service-account JSON supplied through GOOGLE_APPLICATION_CREDENTIALS.
 */
const fs = require("node:fs");
const process = require("node:process");
const admin = require("firebase-admin");

const PROJECT_ID = "adnify-f033d";
const ADMIN_EMAIL = "mdadnan018863@gmail.com";
const credentialsPath = process.env.GOOGLE_APPLICATION_CREDENTIALS;

function fail(message) {
  console.error(`Admin provisioning failed: ${message}`);
  process.exitCode = 1;
}

async function main() {
  if (!credentialsPath) {
    fail("Set GOOGLE_APPLICATION_CREDENTIALS to a service-account JSON path outside the repository.");
    return;
  }
  if (!fs.existsSync(credentialsPath)) {
    fail(`Credential file does not exist: ${credentialsPath}`);
    return;
  }

  const serviceAccount = JSON.parse(fs.readFileSync(credentialsPath, "utf8"));
  if (serviceAccount.project_id && serviceAccount.project_id !== PROJECT_ID) {
    fail(`The credential belongs to ${serviceAccount.project_id}, not ${PROJECT_ID}.`);
    return;
  }

  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    projectId: PROJECT_ID,
  });

  const auth = admin.auth();
  const database = admin.firestore();
  const user = await auth.getUserByEmail(ADMIN_EMAIL);
  const existingClaims = user.customClaims || {};
  const timestamp = admin.firestore.FieldValue.serverTimestamp();

  await auth.setCustomUserClaims(user.uid, {
    ...existingClaims,
    role: "ADMIN",
    admin: true,
  });

  await database.doc(`roles/${user.uid}`).set({
    role: "ADMIN",
    assignedAt: timestamp,
    assignedBy: "local-admin-script",
  }, { merge: true });

  await database.doc(`users/${user.uid}`).set({
    fullName: user.displayName || "Adrox Administrator",
    email: ADMIN_EMAIL,
    requestedRole: "BUSINESS",
    profileComplete: true,
    verificationStatus: "verified",
    accountStatus: "active",
    updatedAt: timestamp,
  }, { merge: true });

  console.log(`Admin claim set successfully for ${ADMIN_EMAIL}.`);
  console.log("Sign out of Adrox, sign in again, and open /admin.");
}

main().catch((error) => {
  if (error?.code === "auth/user-not-found") {
    fail(`No Firebase Auth user exists for ${ADMIN_EMAIL}. Create the account first.`);
    return;
  }
  fail(error?.message || String(error));
});
