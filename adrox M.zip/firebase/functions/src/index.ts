/**
 * Trusted Firebase backend for Adrox. The administrator email is evaluated
 * here—not in React—so a browser can never award itself administrator status.
 */
import * as admin from "firebase-admin";
import { onDocumentCreated, onDocumentUpdated } from "firebase-functions/v2/firestore";
import { HttpsError, onCall } from "firebase-functions/v2/https";

admin.initializeApp();

const ADMIN_EMAIL = "mdadnan018863@gmail.com";
const allowedRoles = new Set(["FDE", "BUSINESS"]);

/**
 * Allows only the pre-designated authenticated Firebase account to bootstrap its
 * administrator records and custom claim. The browser neither supplies nor controls the role.
 */
export const activateAdministrator = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in before requesting administrator access.");

  const email = typeof request.auth.token.email === "string" ? request.auth.token.email.trim().toLowerCase() : "";
  if (email !== ADMIN_EMAIL) throw new HttpsError("permission-denied", "This Firebase account is not the designated administrator.");

  const database = admin.firestore();
  const authUser = await admin.auth().getUser(request.auth.uid);
  const timestamp = admin.firestore.FieldValue.serverTimestamp();

  await database.doc(`users/${request.auth.uid}`).set({
    fullName: authUser.displayName || "Adrox Administrator",
    email,
    requestedRole: "BUSINESS",
    profileComplete: true,
    verificationStatus: "verified",
    accountStatus: "active",
    updatedAt: timestamp,
  }, { merge: true });
  await database.doc(`roles/${request.auth.uid}`).set({ role: "ADMIN", assignedAt: timestamp, assignedBy: "trusted-callable" });
  await admin.auth().setCustomUserClaims(request.auth.uid, { role: "ADMIN", admin: true });

  return { role: "ADMIN" };
});

export const assignAccountRole = onDocumentCreated("users/{uid}", async (event) => {
  const snapshot = event.data;
  if (!snapshot) return;

  const data = snapshot.data();
  const userId = event.params.uid;
  const email = typeof data.email === "string" ? data.email.trim().toLowerCase() : "";
  const requestedRole = typeof data.requestedRole === "string" ? data.requestedRole : "FDE";
  const role = email === ADMIN_EMAIL ? "ADMIN" : allowedRoles.has(requestedRole) ? requestedRole : "FDE";

  await admin.firestore().doc(`roles/${userId}`).set({
    role,
    assignedAt: admin.firestore.FieldValue.serverTimestamp(),
    assignedBy: "system",
  });

  await admin.auth().setCustomUserClaims(userId, {
    role,
    admin: role === "ADMIN",
  });
});

const feeDefaults = { businessFee: 999, fdeFee: 999, paymentInstructions: "Pay using the UPI details below, then submit your transaction ID for Admin verification.", upiId: "", payeeName: "Adrox", qrImageUrl: "" };
const feeSlabs = [
  [1_000, 10_000, 500], [10_000, 50_000, 2_500], [50_000, 100_000, 5_000],
  [100_000, 150_000, 7_500], [150_000, 200_000, 10_000], [200_000, 250_000, 12_500],
  [250_000, 300_000, 15_000], [300_000, 500_000, 20_000], [500_000, 1_000_000, 40_000],
  [1_000_000, 2_000_000, 80_000], [2_000_000, 3_000_000, 100_000], [3_000_000, 5_000_000, 200_000],
];

function calculateSlabFee(value: number) {
  const amount = Math.max(0, Math.round(Number(value) || 0));
  const slab = feeSlabs.find(([minimum, maximum], index) => amount >= minimum && (amount < maximum || index === feeSlabs.length - 1));
  return slab?.[2] ?? 0;
}

export const createConnectionFromAcceptedProposal = onDocumentUpdated("proposals/{proposalId}", async (event) => {
  const before = event.data?.before.data();
  const proposal = event.data?.after.data();
  if (!before || !proposal || before.status === "accepted" || proposal.status !== "accepted") return;

  const database = admin.firestore();
  const connectionRef = database.doc(`connections/${event.params.proposalId}`);
  const configSnapshot = await database.doc("platform_config/default").get();
  const config = { ...feeDefaults, ...(configSnapshot.exists ? configSnapshot.data() : {}) };

  await database.runTransaction(async (transaction) => {
    if ((await transaction.get(connectionRef)).exists) return;
    transaction.set(connectionRef, {
      proposalId: event.params.proposalId,
      problemId: proposal.problemId,
      problemTitle: proposal.problemTitle,
      businessId: proposal.businessId,
      businessName: proposal.businessName,
      fdeId: proposal.fdeId,
      fdeName: proposal.fdeName,
      baseAmount: Number(proposal.proposedBudget),
      businessFeeAmount: Number(proposal.proposedBudget) + calculateSlabFee(Number(proposal.proposedBudget)),
      fdeFeeAmount: Number(proposal.proposedBudget) + calculateSlabFee(Number(proposal.proposedBudget)),
      businessFee: Number(proposal.proposedBudget) + calculateSlabFee(Number(proposal.proposedBudget)),
      fdeFee: Number(proposal.proposedBudget) + calculateSlabFee(Number(proposal.proposedBudget)),
      paymentInstructions: String(config.paymentInstructions),
      upiId: String(config.upiId || ""),
      payeeName: String(config.payeeName || "Adrox"),
      qrImageUrl: String(config.qrImageUrl || ""),
      businessPaymentStatus: "awaiting_payment",
      fdePaymentStatus: "awaiting_payment",
      status: "awaiting_payments",
      contactUnlocked: false,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });
});

export const applyVerifiedPayment = onDocumentUpdated("payment_submissions/{paymentId}", async (event) => {
  const before = event.data?.before.data();
  const payment = event.data?.after.data();
  if (!before || !payment || before.status === "verified" || payment.status !== "verified") return;

  const database = admin.firestore();
  const connectionRef = database.doc(`connections/${payment.connectionId}`);
  await database.runTransaction(async (transaction) => {
    const connectionSnapshot = await transaction.get(connectionRef);
    if (!connectionSnapshot.exists) return;
    const connection = connectionSnapshot.data()!;
    const paymentUpdate = payment.payerRole === "BUSINESS" ? { businessPaymentStatus: "verified" } : { fdePaymentStatus: "verified" };
    const businessPaymentStatus = payment.payerRole === "BUSINESS" ? "verified" : connection.businessPaymentStatus;
    const fdePaymentStatus = payment.payerRole === "FDE" ? "verified" : connection.fdePaymentStatus;
    if (businessPaymentStatus !== "verified" || fdePaymentStatus !== "verified") {
      transaction.update(connectionRef, { ...paymentUpdate, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
      return;
    }

    const [businessContact, fdeContact] = await transaction.getAll(
      database.doc(`private_contacts/${connection.businessId}`),
      database.doc(`private_contacts/${connection.fdeId}`),
    );
    transaction.update(connectionRef, {
      ...paymentUpdate,
      status: "connected",
      contactUnlocked: true,
      businessContact: businessContact.exists ? businessContact.data() : { email: "" },
      fdeContact: fdeContact.exists ? fdeContact.data() : { email: "" },
      connectedAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });
});

export const applyAccountBlock = onDocumentUpdated("users/{uid}", async (event) => {
  const before = event.data?.before.data();
  const user = event.data?.after.data();
  if (!before || !user || before.accountStatus === user.accountStatus) return;
  await admin.auth().updateUser(event.params.uid, { disabled: user.accountStatus === "blocked" });
});

export const markPaymentSubmissionReceived = onDocumentCreated("payment_submissions/{paymentId}", async (event) => {
  const payment = event.data?.data();
  if (!payment) return;
  const connectionRef = admin.firestore().doc(`connections/${payment.connectionId}`);
  await admin.firestore().runTransaction(async (transaction) => {
    const connectionSnapshot = await transaction.get(connectionRef);
    if (!connectionSnapshot.exists) return;
    const patch = payment.payerRole === "BUSINESS" ? { businessPaymentStatus: "submitted" } : { fdePaymentStatus: "submitted" };
    transaction.update(connectionRef, { ...patch, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  });
});

export const applyRejectedOrRefundedPayment = onDocumentUpdated("payment_submissions/{paymentId}", async (event) => {
  const before = event.data?.before.data();
  const payment = event.data?.after.data();
  if (!before || !payment || before.status === payment.status || !["rejected", "refunded"].includes(payment.status)) return;
  const connectionRef = admin.firestore().doc(`connections/${payment.connectionId}`);
  const patch = payment.payerRole === "BUSINESS"
    ? { businessPaymentStatus: payment.status === "refunded" ? "refunded" : "awaiting_payment" }
    : { fdePaymentStatus: payment.status === "refunded" ? "refunded" : "awaiting_payment" };
  await connectionRef.update({
    ...patch,
    status: payment.status === "refunded" ? "disputed" : "awaiting_payments",
    contactUnlocked: false,
    businessContact: admin.firestore.FieldValue.delete(),
    fdeContact: admin.firestore.FieldValue.delete(),
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });
});


/**
 * Local QA helper only. It is deliberately unusable in deployed Firebase
 * Functions, so it cannot bypass real payment verification in production.
 */
export const mockVerifyPayment = onCall(async (request) => {
  if (process.env.FUNCTIONS_EMULATOR !== "true") {
    throw new HttpsError("failed-precondition", "Mock payment verification is available only in the Firebase Emulator Suite.");
  }
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in to test a local payment.");
  const connectionId = typeof request.data?.connectionId === "string" ? request.data.connectionId : "";
  if (!connectionId) throw new HttpsError("invalid-argument", "connectionId is required.");

  const database = admin.firestore();
  const connectionRef = database.doc(`connections/${connectionId}`);
  const connectionSnapshot = await connectionRef.get();
  if (!connectionSnapshot.exists) throw new HttpsError("not-found", "Connection not found in the local emulator.");
  const connection = connectionSnapshot.data()!;
  const payerRole = connection.businessId === request.auth.uid ? "BUSINESS" : connection.fdeId === request.auth.uid ? "FDE" : null;
  if (!payerRole) throw new HttpsError("permission-denied", "You are not a participant in this connection.");

  const payments = await database.collection("payment_submissions")
    .where("connectionId", "==", connectionId)
    .where("payerRole", "==", payerRole)
    .where("status", "==", "submitted")
    .get();
  if (payments.empty) throw new HttpsError("failed-precondition", "Submit a local payment reference before verifying it.");

  const paymentRef = payments.docs[0].ref;
  await database.runTransaction(async (transaction) => {
    const currentConnection = (await transaction.get(connectionRef)).data();
    if (!currentConnection) throw new HttpsError("not-found", "Connection not found.");
    transaction.update(paymentRef, { status: "verified", reviewedAt: admin.firestore.FieldValue.serverTimestamp(), reviewedBy: "local-emulator" });
    const nextBusiness = payerRole === "BUSINESS" ? "verified" : currentConnection.businessPaymentStatus;
    const nextFde = payerRole === "FDE" ? "verified" : currentConnection.fdePaymentStatus;
    const patch: Record<string, unknown> = {
      businessPaymentStatus: nextBusiness,
      fdePaymentStatus: nextFde,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    };
    if (nextBusiness === "verified" && nextFde === "verified") {
      const [businessContact, fdeContact] = await transaction.getAll(
        database.doc(`private_contacts/${currentConnection.businessId}`),
        database.doc(`private_contacts/${currentConnection.fdeId}`),
      );
      patch.status = "connected";
      patch.contactUnlocked = true;
      patch.businessContact = businessContact.exists ? businessContact.data() : { email: "" };
      patch.fdeContact = fdeContact.exists ? fdeContact.data() : { email: "" };
      patch.connectedAt = admin.firestore.FieldValue.serverTimestamp();
    }
    transaction.update(connectionRef, patch);
  });
  return { verified: true };
});
