#!/usr/bin/env bash
# Deploys Adrox's Firebase-only backend without embedding service-account credentials.
set -euo pipefail

if [[ -z "${GOOGLE_APPLICATION_CREDENTIALS:-}" ]]; then
  echo "Set GOOGLE_APPLICATION_CREDENTIALS to the path of the adnify-f033d service-account JSON before deploying." >&2
  exit 1
fi

if [[ ! -f "$GOOGLE_APPLICATION_CREDENTIALS" ]]; then
  echo "The service-account JSON path does not exist: $GOOGLE_APPLICATION_CREDENTIALS" >&2
  exit 1
fi

cd "$(dirname "$0")/.."
npx --yes firebase-tools@latest deploy --project adnify-f033d --only functions,firestore:rules,storage
