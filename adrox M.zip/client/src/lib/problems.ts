/**
 * Firebase problem records for Adrox. Business users own writes; published records
 * are intentionally readable to Forward Deployed Engineers through Firestore rules.
 */
import {
  addDoc,
  collection,
  onSnapshot,
  query,
  serverTimestamp,
  where,
  type Timestamp,
} from "firebase/firestore";
import { db } from "./firebase";

export type ProblemStatus = "pending" | "published" | "rejected" | "draft" | "paused" | "closed";

export interface ProblemRecord {
  id: string;
  businessId: string;
  businessName: string;
  title: string;
  industry: string;
  location: string;
  workMode: "Remote" | "Hybrid" | "On site";
  currentProcess: string;
  expectedOutcome: string;
  budgetMin: number;
  budgetMax: number;
  status: ProblemStatus;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface ProblemInput {
  title: string;
  industry: string;
  location: string;
  workMode: ProblemRecord["workMode"];
  currentProcess: string;
  expectedOutcome: string;
  budgetMin: number;
  budgetMax: number;
}

function sortNewest(problems: ProblemRecord[]) {
  return [...problems].sort((first, second) => (second.createdAt?.toMillis() ?? 0) - (first.createdAt?.toMillis() ?? 0));
}

export async function createProblem(input: ProblemInput, owner: { uid: string; businessName: string }) {
  const cleanInput = {
    title: input.title.trim(),
    industry: input.industry.trim(),
    location: input.location.trim(),
    workMode: input.workMode,
    currentProcess: input.currentProcess.trim(),
    expectedOutcome: input.expectedOutcome.trim(),
    budgetMin: Number(input.budgetMin),
    budgetMax: Number(input.budgetMax),
  };

  return addDoc(collection(db, "problems"), {
    ...cleanInput,
    businessId: owner.uid,
    businessName: owner.businessName.trim() || "Verified business",
    status: "published" satisfies ProblemStatus,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
}

export function subscribeToBusinessProblems(businessId: string, onUpdate: (problems: ProblemRecord[]) => void, onError: (error: Error) => void) {
  const businessQuery = query(collection(db, "problems"), where("businessId", "==", businessId));
  return onSnapshot(businessQuery, (snapshot) => onUpdate(sortNewest(snapshot.docs.map((entry) => ({ id: entry.id, ...entry.data() } as ProblemRecord)))), onError);
}

export function subscribeToPublishedProblems(onUpdate: (problems: ProblemRecord[]) => void, onError: (error: Error) => void) {
  const feedQuery = query(collection(db, "problems"), where("status", "==", "published"));
  return onSnapshot(feedQuery, (snapshot) => onUpdate(sortNewest(snapshot.docs.map((entry) => ({ id: entry.id, ...entry.data() } as ProblemRecord)))), onError);
}

export function formatBudget(problem: Pick<ProblemRecord, "budgetMin" | "budgetMax">) {
  const formatter = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 });
  return `${formatter.format(problem.budgetMin)} – ${formatter.format(problem.budgetMax)}`;
}

export function formatPostedDate(problem: Pick<ProblemRecord, "createdAt">) {
  if (!problem.createdAt) return "Just now";
  return new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short", year: "numeric" }).format(problem.createdAt.toDate());
}
