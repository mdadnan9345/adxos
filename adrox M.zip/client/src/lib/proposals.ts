/**
 * Proposal and connection-request records for Adrox. A proposal belongs only to
 * the responding FDE and the Business that published the target problem.
 */
import { addDoc, collection, doc, getDoc, onSnapshot, query, runTransaction, serverTimestamp, where, type Timestamp } from "firebase/firestore";
import { db } from "./firebase";
import { getConnectionCharge } from "./fees";

export type ProposalStatus = "submitted" | "accepted" | "declined";

export interface ProposalRecord {
  id: string;
  problemId: string;
  problemTitle: string;
  businessId: string;
  businessName: string;
  fdeId: string;
  fdeName: string;
  approach: string;
  deliveryWindow: string;
  proposedBudget: number;
  status: ProposalStatus;
  businessResponse?: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface ProposalInput {
  approach: string;
  deliveryWindow: string;
  proposedBudget: number;
}

function sortNewest(proposals: ProposalRecord[]) {
  return [...proposals].sort((first, second) => (second.createdAt?.toMillis() ?? 0) - (first.createdAt?.toMillis() ?? 0));
}

export async function submitProposal(input: ProposalInput, context: Omit<ProposalRecord, "id" | "approach" | "deliveryWindow" | "proposedBudget" | "status" | "createdAt" | "updatedAt">) {
  return addDoc(collection(db, "proposals"), {
    ...context,
    approach: input.approach.trim(),
    deliveryWindow: input.deliveryWindow.trim(),
    proposedBudget: Number(input.proposedBudget),
    status: "submitted" satisfies ProposalStatus,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
}

export function subscribeToFdeProposals(fdeId: string, onUpdate: (proposals: ProposalRecord[]) => void, onError: (error: Error) => void) {
  return onSnapshot(query(collection(db, "proposals"), where("fdeId", "==", fdeId)), (snapshot) => onUpdate(sortNewest(snapshot.docs.map((entry) => ({ id: entry.id, ...entry.data() } as ProposalRecord)))), onError);
}

export function subscribeToBusinessProposals(businessId: string, onUpdate: (proposals: ProposalRecord[]) => void, onError: (error: Error) => void) {
  return onSnapshot(query(collection(db, "proposals"), where("businessId", "==", businessId)), (snapshot) => onUpdate(sortNewest(snapshot.docs.map((entry) => ({ id: entry.id, ...entry.data() } as ProposalRecord)))), onError);
}

export function decideProposal(proposalId: string, decision: Extract<ProposalStatus, "accepted" | "declined">) {
  const proposalRef = doc(db, "proposals", proposalId);
  if (decision === "declined") return runTransaction(db, async (transaction) => {
    transaction.update(proposalRef, { status: decision, businessResponse: "The Business has chosen another approach for this problem.", updatedAt: serverTimestamp() });
  });
  return runTransaction(db, async (transaction) => {
    const proposalSnapshot = await transaction.get(proposalRef);
    if (!proposalSnapshot.exists()) throw new Error("Proposal not found.");
    const proposal = proposalSnapshot.data() as Omit<ProposalRecord, "id">;
    if (proposal.status !== "submitted") throw new Error("This proposal has already been decided.");
    const configSnapshot = await transaction.get(doc(db, "platform_config", "default"));
    const config = configSnapshot.exists() ? configSnapshot.data() : {};
    const baseAmount = Number(proposal.proposedBudget);
    const charge = getConnectionCharge(baseAmount);
    const connectionRef = doc(db, "connections", proposalId);
    transaction.update(proposalRef, { status: "accepted", businessResponse: "Connection request accepted. Your payment page is ready.", updatedAt: serverTimestamp() });
    transaction.set(connectionRef, {
      proposalId,
      problemId: proposal.problemId,
      problemTitle: proposal.problemTitle,
      businessId: proposal.businessId,
      businessName: proposal.businessName,
      fdeId: proposal.fdeId,
      fdeName: proposal.fdeName,
      baseAmount,
      businessFeeAmount: charge.feeAmount,
      fdeFeeAmount: charge.feeAmount,
      businessFee: charge.feeAmount,
      fdeFee: charge.feeAmount,
      paymentInstructions: String(config.paymentInstructions || "Pay using the UPI details below, then submit your transaction ID for Admin verification."),
      upiId: String(config.upiId || ""),
      payeeName: String(config.payeeName || "Adrox"),
      qrImageUrl: String(config.qrImageUrl || ""),
      businessPaymentStatus: "awaiting_payment",
      fdePaymentStatus: "awaiting_payment",
      status: "awaiting_payments",
      contactUnlocked: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }, { merge: true });
  });
}

export function formatProposedBudget(value: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
}
