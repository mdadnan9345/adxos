/**
 * Firebase administrator workspace data helpers. All mutations require the
 * `admin` Firebase custom claim, enforced again by Firestore rules.
 */
import { collection, doc, onSnapshot, runTransaction, serverTimestamp, setDoc, updateDoc, type Timestamp } from "firebase/firestore";
import { db } from "./firebase";
import type { ConnectionRecord } from "./connections";
import type { ProblemRecord } from "./problems";
import type { ReportRecord } from "./connections";

export interface AdminUserRecord { id: string; fullName: string; email: string; requestedRole: "FDE" | "BUSINESS"; verificationStatus?: "pending" | "verified" | "rejected"; accountStatus?: "active" | "blocked"; createdAt?: Timestamp; }
export interface PaymentSubmissionRecord { id: string; connectionId: string; problemTitle: string; businessId: string; businessName: string; fdeId: string; fdeName: string; payerId: string; payerRole: "BUSINESS" | "FDE"; amount: number; paymentReference: string; status: "submitted" | "verified" | "rejected" | "refunded"; submittedAt?: Timestamp; }
export interface PlatformConfig { businessFee: number; fdeFee: number; paymentInstructions: string; upiId: string; payeeName: string; qrImageUrl: string; }
export const defaultPlatformConfig: PlatformConfig = { businessFee: 999, fdeFee: 999, paymentInstructions: "Pay using the UPI details below, then submit your transaction ID for Admin verification.", upiId: "", payeeName: "Adrox", qrImageUrl: "" };

function subscribeCollection<T>(name: string, onUpdate: (records: T[]) => void, onError: (error: Error) => void) {
  return onSnapshot(collection(db, name), (snapshot) => onUpdate(snapshot.docs.map((entry) => ({ id: entry.id, ...entry.data() } as T))), onError);
}

export const subscribeToAdminUsers = (onUpdate: (records: AdminUserRecord[]) => void, onError: (error: Error) => void) => subscribeCollection<AdminUserRecord>("users", onUpdate, onError);
export const subscribeToAdminProblems = (onUpdate: (records: ProblemRecord[]) => void, onError: (error: Error) => void) => subscribeCollection<ProblemRecord>("problems", onUpdate, onError);
export const subscribeToAdminPayments = (onUpdate: (records: PaymentSubmissionRecord[]) => void, onError: (error: Error) => void) => subscribeCollection<PaymentSubmissionRecord>("payment_submissions", onUpdate, onError);
export const subscribeToAdminConnections = (onUpdate: (records: ConnectionRecord[]) => void, onError: (error: Error) => void) => subscribeCollection<ConnectionRecord>("connections", onUpdate, onError);
export const subscribeToAdminReports = (onUpdate: (records: ReportRecord[]) => void, onError: (error: Error) => void) => subscribeCollection<ReportRecord>("reports", onUpdate, onError);
export const subscribeToPlatformConfig = (onUpdate: (value: PlatformConfig) => void, onError: (error: Error) => void) => onSnapshot(doc(db, "platform_config", "default"), (snapshot) => onUpdate(snapshot.exists() ? snapshot.data() as PlatformConfig : defaultPlatformConfig), onError);
export const updateUserAdminState = (userId: string, data: Partial<Pick<AdminUserRecord, "verificationStatus" | "accountStatus">>) => updateDoc(doc(db, "users", userId), { ...data, updatedAt: new Date() });
export const decideProblemAdminState = (problemId: string, status: "published" | "rejected") => updateDoc(doc(db, "problems", problemId), { status, updatedAt: new Date() });
export async function decidePaymentAdminState(paymentId: string, status: PaymentSubmissionRecord["status"]) {
  if (status === "verified") {
    await runTransaction(db, async (transaction) => {
      const paymentRef = doc(db, "payment_submissions", paymentId);
      const paymentSnapshot = await transaction.get(paymentRef);
      if (!paymentSnapshot.exists()) throw new Error("Payment submission not found.");
      const payment = paymentSnapshot.data() as PaymentSubmissionRecord;
      if (payment.status !== "submitted") throw new Error("Only submitted payments can be verified.");
      const connectionRef = doc(db, "connections", payment.connectionId);
      const connectionSnapshot = await transaction.get(connectionRef);
      if (!connectionSnapshot.exists()) throw new Error("Connection not found.");
      const connection = connectionSnapshot.data() as ConnectionRecord;
      const businessContactRef = doc(db, "private_contacts", connection.businessId);
      const fdeContactRef = doc(db, "private_contacts", connection.fdeId);
      const businessContactSnapshot = await transaction.get(businessContactRef);
      const fdeContactSnapshot = await transaction.get(fdeContactRef);
      const businessVerified = payment.payerRole === "BUSINESS" || connection.businessPaymentStatus === "verified";
      const fdeVerified = payment.payerRole === "FDE" || connection.fdePaymentStatus === "verified";
      const update: Record<string, any> = {
        [payment.payerRole === "BUSINESS" ? "businessPaymentStatus" : "fdePaymentStatus"]: "verified",
        updatedAt: serverTimestamp(),
      };
      if (businessVerified && fdeVerified) {
        update.status = "connected";
        update.contactUnlocked = true;
        update.businessContact = businessContactSnapshot.exists() ? businessContactSnapshot.data() : { email: "" };
        update.fdeContact = fdeContactSnapshot.exists() ? fdeContactSnapshot.data() : { email: "" };
        update.connectedAt = serverTimestamp();
      }
      transaction.update(paymentRef, { status: "verified", reviewedAt: serverTimestamp() });
      transaction.update(connectionRef, update);
    });
    return;
  }
  await runTransaction(db, async (transaction) => {
    const paymentRef = doc(db, "payment_submissions", paymentId);
    const paymentSnapshot = await transaction.get(paymentRef);
    if (!paymentSnapshot.exists()) throw new Error("Payment submission not found.");
    const payment = paymentSnapshot.data() as PaymentSubmissionRecord;
    const connectionRef = doc(db, "connections", payment.connectionId);
    transaction.update(paymentRef, { status, reviewedAt: serverTimestamp() });
    transaction.update(connectionRef, {
      [payment.payerRole === "BUSINESS" ? "businessPaymentStatus" : "fdePaymentStatus"]: status === "refunded" ? "refunded" : "awaiting_payment",
      status: status === "refunded" ? "disputed" : "awaiting_payments",
      contactUnlocked: false,
      businessContact: null,
      fdeContact: null,
      updatedAt: serverTimestamp(),
    });
  });
}
export const decideReportAdminState = (reportId: string, status: ReportRecord["status"]) => updateDoc(doc(db, "reports", reportId), { status, reviewedAt: new Date() });
export const savePlatformConfig = (data: PlatformConfig) => setDoc(doc(db, "platform_config", "default"), data, { merge: true });
