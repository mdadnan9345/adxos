/**
 * Role resolution for Adrox. Account types are read from locked user metadata or
 * trusted claims; this module never trusts a mutable value supplied by the UI.
 */
import { doc, getDoc } from "firebase/firestore";
import { db } from "./firebase";

export type AccountRole = "FDE" | "BUSINESS" | "ADMIN" | null;

export async function getAccountRole(userId: string): Promise<AccountRole> {
  const roleDocument = await getDoc(doc(db, "roles", userId));
  if (roleDocument.exists()) {
    const role = roleDocument.data().role;
    if (role === "FDE" || role === "BUSINESS" || role === "ADMIN") return role;
  }

  const userDocument = await getDoc(doc(db, "users", userId));
  if (userDocument.exists()) {
    const role = userDocument.data().requestedRole;
    if (role === "FDE" || role === "BUSINESS") return role;
  }

  return null;
}
