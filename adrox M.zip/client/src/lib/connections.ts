/**
 * Firebase connection records for Adrox. Contacts are copied into a connection
 * only by trusted Firebase Functions after both fees receive admin verification.
 */
import { addDoc, collection, doc, onSnapshot, query, setDoc, updateDoc, where, type Timestamp } from "firebase/firestore";
import { db } from "./firebase";
import { functions, isFirebaseEmulatorMode } from "./firebase";
import { httpsCallable } from "firebase/functions";
import { getConnectionCharge } from "./fees";

export type PaymentStatus = "awaiting_payment" | "submitted" | "verified" | "refunded";
export type ConnectionStatus = "awaiting_payments" | "connected" | "cancelled" | "disputed";

export interface ContactCard {
  email: string;
  phone: string;
  whatsapp: string;
}

export interface ConnectionRecord {
  id: string;
  proposalId: string;
  problemId: string;
  problemTitle: string;
  businessId: string;
  businessName: string;
  fdeId: string;
  fdeName: string;
  baseAmount?: number;
  businessFeeAmount?: number;
  fdeFeeAmount?: number;
  businessFee: number;
  fdeFee: number;
  paymentInstructions?: string;
  upiId?: string;
  payeeName?: string;
  qrImageUrl?: string;
  businessPaymentStatus: PaymentStatus;
  fdePaymentStatus: PaymentStatus;
  status: ConnectionStatus;
  contactUnlocked: boolean;
  businessContact?: ContactCard;
  fdeContact?: ContactCard;
  createdAt?: Timestamp;
}

export interface ReportRecord {
  id: string;
  connectionId: string;
  reporterId: string;
  reporterRole: "BUSINESS" | "FDE";
  problemTitle: string;
  detail: string;
  status: "open" | "resolved";
  createdAt?: Timestamp;
}

function sortNewest(records: ConnectionRecord[]) {
  return [...records].sort((first, second) => (second.createdAt?.toMillis() ?? 0) - (first.createdAt?.toMillis() ?? 0));
}

export function subscribeToConnections(userId: string, role: "BUSINESS" | "FDE", onUpdate: (records: ConnectionRecord[]) => void, onError: (error: Error) => void) {
  const field = role === "BUSINESS" ? "businessId" : "fdeId";
  return onSnapshot(query(collection(db, "connections"), where(field, "==", userId)), (snapshot) => onUpdate(sortNewest(snapshot.docs.map((entry) => ({ id: entry.id, ...entry.data() } as ConnectionRecord)))), onError);
}

export function subscribeToPrivateContact(userId: string, onUpdate: (contact: ContactCard | null) => void, onError: (error: Error) => void) {
  return onSnapshot(doc(db, "private_contacts", userId), (snapshot) => onUpdate(snapshot.exists() ? snapshot.data() as ContactCard : null), onError);
}

export function updatePrivateContact(userId: string, contact: ContactCard) {
  return setDoc(doc(db, "private_contacts", userId), { ...contact, updatedAt: new Date() }, { merge: true });
}

export function submitPaymentReference(connection: ConnectionRecord, payer: { id: string; role: "BUSINESS" | "FDE" }, reference: string) {
  const amount = getPaymentBreakdown(connection, payer.role).totalAmount;
  return addDoc(collection(db, "payment_submissions"), {
    connectionId: connection.id,
    problemTitle: connection.problemTitle,
    businessId: connection.businessId,
    businessName: connection.businessName,
    fdeId: connection.fdeId,
    fdeName: connection.fdeName,
    payerId: payer.id,
    payerRole: payer.role,
    amount,
    paymentReference: reference.trim(),
    status: "submitted",
    submittedAt: new Date(),
  });
}

export function formatConnectionFee(value: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
}

export function getPaymentBreakdown(connection: ConnectionRecord, payer: "BUSINESS" | "FDE") {
  const legacyTotal = payer === "BUSINESS" ? (connection.businessFeeAmount ?? connection.businessFee) : (connection.fdeFeeAmount ?? connection.fdeFee);
  const baseAmount = connection.baseAmount ?? legacyTotal;
  const calculated = getConnectionCharge(baseAmount);
  const totalAmount = connection.baseAmount === undefined ? legacyTotal : (payer === "BUSINESS" ? (connection.businessFeeAmount ?? calculated.feeAmount) : (connection.fdeFeeAmount ?? calculated.feeAmount));
  return { baseAmount, feeAmount: calculated.feeAmount, totalAmount: totalAmount === baseAmount + calculated.feeAmount ? calculated.feeAmount : totalAmount };
}

export function updateConnectionAdminStatus(connectionId: string, status: ConnectionStatus) {
  return updateDoc(doc(db, "connections", connectionId), { status, updatedAt: new Date() });
}

export async function mockVerifyLocalPayment(connectionId: string) {
  if (!isFirebaseEmulatorMode) throw new Error("Local payment verification is disabled outside the Firebase Emulator Suite.");
  await httpsCallable<{ connectionId: string }, { verified: boolean }>(functions, "mockVerifyPayment")({ connectionId });
}

export function submitConnectionReport(connection: ConnectionRecord, reporter: { id: string; role: "BUSINESS" | "FDE" }, detail: string) {
  return addDoc(collection(db, "reports"), {
    connectionId: connection.id,
    reporterId: reporter.id,
    reporterRole: reporter.role,
    problemTitle: connection.problemTitle,
    detail: detail.trim(),
    status: "open",
    createdAt: new Date(),
  });
}
