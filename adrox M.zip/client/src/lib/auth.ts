/**
 * Adrox's client authentication helpers. The browser may request FDE or
 * Business onboarding, but administrator privileges are assigned only by Firebase Functions.
 */
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  type UserCredential,
} from "firebase/auth";
import { doc, serverTimestamp, setDoc } from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { getAccountRole, type AccountRole } from "./account";
import { createFdeDirectoryRecord } from "./fdes";
import { updatePrivateContact } from "./connections";
import { auth, db, functions } from "./firebase";

export type RequestedRole = "FDE" | "BUSINESS";

export async function registerAccount({
  name,
  email,
  password,
  requestedRole,
}: {
  name: string;
  email: string;
  password: string;
  requestedRole: RequestedRole;
}): Promise<UserCredential> {
  const credential = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(credential.user, { displayName: name.trim() });

  await setDoc(doc(db, "users", credential.user.uid), {
    fullName: name,
    email: credential.user.email?.toLowerCase() ?? email.toLowerCase(),
    requestedRole,
    profileComplete: false,
    verificationStatus: "pending",
    accountStatus: "active",
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  await updatePrivateContact(credential.user.uid, { email: credential.user.email?.toLowerCase() ?? email.toLowerCase(), phone: "", whatsapp: "" });

  if (requestedRole === "FDE") {
    await createFdeDirectoryRecord(credential.user.uid, name);
  }

  return credential;
}

export function loginAccount(email: string, password: string) {
  return signInWithEmailAndPassword(auth, email, password);
}

export function logoutAccount() {
  return signOut(auth);
}

/** Runs after login only when no account role exists. Server-side email validation makes this safe. */
export async function activateDesignatedAdministrator() {
  await httpsCallable(functions, "activateAdministrator")();
  await auth.currentUser?.getIdToken(true);
}

export async function redirectPathForUser(userId: string, registrationRole?: RequestedRole) {
  const role: AccountRole = registrationRole ?? await getAccountRole(userId);
  if (role === "FDE") return "/fde";
  if (role === "BUSINESS") return "/business";
  if (role === "ADMIN") return "/admin";
  return "/";
}

export function readableAuthError(error: unknown) {
  const code = typeof error === "object" && error && "code" in error ? String(error.code) : "";

  if (code.includes("invalid-credential") || code.includes("wrong-password") || code.includes("user-not-found")) {
    return "The email or password is not recognised. Please try again.";
  }
  if (code.includes("email-already-in-use")) return "An account already exists for this email. Please log in instead.";
  if (code.includes("weak-password")) return "Use a password with at least six characters.";
  if (code.includes("invalid-email")) return "Enter a valid email address.";
  if (code.includes("permission-denied")) return "Your account was created, but profile setup is still being enabled. Please try again shortly.";

  return "We could not complete that request. Please check your connection and try again.";
}
