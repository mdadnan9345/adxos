export interface FeeSlab {
  minimum: number;
  maximum: number;
  fee: number;
}

export const CONNECTION_FEE_SLABS: FeeSlab[] = [
  { minimum: 1_000, maximum: 10_000, fee: 500 },
  { minimum: 10_000, maximum: 50_000, fee: 2_500 },
  { minimum: 50_000, maximum: 100_000, fee: 5_000 },
  { minimum: 100_000, maximum: 150_000, fee: 7_500 },
  { minimum: 150_000, maximum: 200_000, fee: 10_000 },
  { minimum: 200_000, maximum: 250_000, fee: 12_500 },
  { minimum: 250_000, maximum: 300_000, fee: 15_000 },
  { minimum: 300_000, maximum: 500_000, fee: 20_000 },
  { minimum: 500_000, maximum: 1_000_000, fee: 40_000 },
  { minimum: 1_000_000, maximum: 2_000_000, fee: 80_000 },
  { minimum: 2_000_000, maximum: 3_000_000, fee: 100_000 },
  { minimum: 3_000_000, maximum: 5_000_000, fee: 200_000 },
];

export function getConnectionFee(baseAmount: number): number {
  const amount = Math.max(0, Math.round(Number(baseAmount) || 0));
  const slab = CONNECTION_FEE_SLABS.find((candidate, index) => amount >= candidate.minimum && (amount < candidate.maximum || index === CONNECTION_FEE_SLABS.length - 1));
  return slab?.fee ?? 0;
}

export function getConnectionCharge(baseAmount: number) {
  const normalizedBase = Math.max(0, Math.round(Number(baseAmount) || 0));
  const fee = getConnectionFee(normalizedBase);
  return { baseAmount: normalizedBase, feeAmount: fee, totalAmount: normalizedBase + fee };
}

export function formatINR(value: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
}

export function getFeeSlabLabel(baseAmount: number) {
  const amount = Math.max(0, Math.round(Number(baseAmount) || 0));
  const slab = CONNECTION_FEE_SLABS.find((candidate, index) => amount >= candidate.minimum && (amount < candidate.maximum || index === CONNECTION_FEE_SLABS.length - 1));
  return slab ? `${formatINR(slab.minimum)} – ${formatINR(slab.maximum)} slab` : "Below the minimum slab";
}

declare global {
  interface Window {
    Razorpay?: new (options: Record<string, unknown>) => { open: () => void };
  }
}

export async function openRazorpayCheckout(options: {
  amount: number;
  name: string;
  email: string;
  description: string;
  onSuccess: (paymentId: string) => void;
  onFailure: () => void;
}) {
  const keyId = import.meta.env.VITE_RAZORPAY_KEY_ID as string | undefined;
  if (!keyId) throw new Error("Razorpay is not configured yet. Add VITE_RAZORPAY_KEY_ID in Netlify environment variables.");
  if (!window.Razorpay) {
    await new Promise<void>((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => resolve();
      script.onerror = () => reject(new Error("Razorpay Checkout could not be loaded."));
      document.head.appendChild(script);
    });
  }
  if (!window.Razorpay) throw new Error("Razorpay Checkout is unavailable.");
  const checkout = new window.Razorpay({
    key: keyId,
    amount: Math.round(options.amount * 100),
    currency: "INR",
    name: "Adrox",
    description: options.description,
    prefill: { email: options.email, name: options.name },
    theme: { color: "#ff684a" },
    handler: (response: { razorpay_payment_id?: string }) => {
      if (response.razorpay_payment_id) options.onSuccess(response.razorpay_payment_id);
      else options.onFailure();
    },
    modal: { ondismiss: options.onFailure },
  });
  checkout.open();
}
