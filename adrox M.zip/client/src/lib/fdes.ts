/**
 * Public Forward Deployed Engineer directory for the Adrox Business workspace.
 * Only non-sensitive fields are stored here; contact details never enter this collection.
 */
import { collection, onSnapshot, query, serverTimestamp, setDoc, doc, type Timestamp } from "firebase/firestore";
import { db } from "./firebase";

export interface FdeDirectoryRecord {
  id: string;
  fullName: string;
  professionalTitle: string;
  location: string;
  availability: string;
  createdAt?: Timestamp;
}

export async function createFdeDirectoryRecord(userId: string, fullName: string) {
  await setDoc(doc(db, "fde_directory", userId), {
    fullName: fullName.trim(),
    professionalTitle: "Forward Deployed Engineer",
    location: "Location to be added",
    availability: "Profile in progress",
    createdAt: serverTimestamp(),
  });
}

export function updateFdeDirectoryRecord(userId: string, profile: Pick<FdeDirectoryRecord, "fullName" | "professionalTitle" | "location" | "availability">) {
  return setDoc(doc(db, "fde_directory", userId), {
    fullName: profile.fullName.trim(),
    professionalTitle: profile.professionalTitle.trim(),
    location: profile.location.trim(),
    availability: profile.availability.trim(),
    updatedAt: new Date(),
  }, { merge: true });
}

export function subscribeToFdeProfile(userId: string, onUpdate: (profile: FdeDirectoryRecord | null) => void, onError: (error: Error) => void) {
  return onSnapshot(doc(db, "fde_directory", userId), (snapshot) => onUpdate(snapshot.exists() ? ({ id: snapshot.id, ...snapshot.data() } as FdeDirectoryRecord) : null), onError);
}

export function subscribeToFdeDirectory(onUpdate: (fdes: FdeDirectoryRecord[]) => void, onError: (error: Error) => void) {
  return onSnapshot(query(collection(db, "fde_directory")), (snapshot) => {
    const records = snapshot.docs.map((entry) => ({ id: entry.id, ...entry.data() } as FdeDirectoryRecord));
    records.sort((first, second) => first.fullName.localeCompare(second.fullName));
    onUpdate(records);
  }, onError);
}
