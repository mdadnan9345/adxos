/**
 * Firebase client boundary for Adrox. This module contains only the public web
 * configuration; administrator credentials and payment secrets never belong here.
 */
import { initializeApp } from "firebase/app";
import { connectAuthEmulator, getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getFunctions } from "firebase/functions";
import { connectFirestoreEmulator } from "firebase/firestore";
import { connectFunctionsEmulator } from "firebase/functions";

const firebaseConfig = {
  apiKey: "AIzaSyAIFZxSnOIbfEd2Q9mlpdl9OfPwIsIZyGU",
  authDomain: "adnify-f033d.firebaseapp.com",
  projectId: "adnify-f033d",
  storageBucket: "adnify-f033d.firebasestorage.app",
  messagingSenderId: "45293668349",
  appId: "1:45293668349:web:1da72d7f207c422a05bb94",
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const functions = getFunctions(app);

export const isFirebaseEmulatorMode = import.meta.env.VITE_USE_FIREBASE_EMULATORS === "true";

if (isFirebaseEmulatorMode) {
  connectAuthEmulator(auth, "http://127.0.0.1:9099", { disableWarnings: true });
  connectFirestoreEmulator(db, "127.0.0.1", 8080);
  connectFunctionsEmulator(functions, "127.0.0.1", 5001);
}
