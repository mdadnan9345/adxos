/**
 * React session hook for the Adrox role-specific workspace. It waits for Firebase
 * Auth and resolves the server-controlled Business or FDE account role.
 */
import { onAuthStateChanged, type User } from "firebase/auth";
import { useEffect, useState } from "react";
import { getAccountRole, type AccountRole } from "@/lib/account";
import { auth } from "@/lib/firebase";

export function useAdroxSession() {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<AccountRole>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    return onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      if (!nextUser) {
        setRole(null);
        setIsLoading(false);
        return;
      }

      try {
        setRole(await getAccountRole(nextUser.uid));
      } catch {
        setRole(null);
      } finally {
        setIsLoading(false);
      }
    });
  }, []);

  return { user, role, isLoading };
}
