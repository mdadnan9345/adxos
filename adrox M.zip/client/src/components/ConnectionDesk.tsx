import { CheckCircle2, Flag, LockKeyhole, Mail, Phone, Send, ShieldCheck, Smartphone, X } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { useAdroxSession } from "@/hooks/useAdroxSession";
import { formatConnectionFee, getPaymentBreakdown, mockVerifyLocalPayment, submitConnectionReport, submitPaymentReference, subscribeToConnections, subscribeToPrivateContact, updatePrivateContact, type ConnectionRecord, type ContactCard } from "@/lib/connections";
import { isFirebaseEmulatorMode } from "@/lib/firebase";
import { getFeeSlabLabel, openRazorpayCheckout } from "@/lib/fees";

interface ConnectionDeskProps { viewerRole: "BUSINESS" | "FDE"; }
const blankContact: ContactCard = { email: "", phone: "", whatsapp: "" };

function paymentLabel(status: string) {
  if (status === "verified") return "Fee verified";
  if (status === "submitted") return "Awaiting verification";
  if (status === "refunded") return "Refund recorded";
  return "Fee due";
}

export default function ConnectionDesk({ viewerRole }: ConnectionDeskProps) {
  const { user } = useAdroxSession();
  const [connections, setConnections] = useState<ConnectionRecord[]>([]);
  const [contact, setContact] = useState<ContactCard>(blankContact);
  const [activePayment, setActivePayment] = useState<ConnectionRecord | null>(null);
  const [paymentReference, setPaymentReference] = useState("");
  const [activeReport, setActiveReport] = useState<ConnectionRecord | null>(null);
  const [reportDetail, setReportDetail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!user) return;
    return subscribeToConnections(user.uid, viewerRole, setConnections, () => toast.error("Connections will appear here once Firebase rules are deployed."));
  }, [user, viewerRole]);

  useEffect(() => {
    if (activePayment || connections.length === 0) return;
    const paymentDue = connections.find((connection) => (viewerRole === "BUSINESS" ? connection.businessPaymentStatus : connection.fdePaymentStatus) === "awaiting_payment");
    if (paymentDue) setActivePayment(paymentDue);
  }, [connections, viewerRole]);

  useEffect(() => {
    if (!user) return;
    return subscribeToPrivateContact(user.uid, (nextContact) => setContact(nextContact ?? { ...blankContact, email: user.email ?? "" }), () => toast.error("Your private contact card could not be loaded."));
  }, [user]);

  async function saveContact(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!user) return;
    try { await updatePrivateContact(user.uid, contact); toast.success("Your private contact card has been saved."); }
    catch { toast.error("Your contact card could not be saved. Confirm Firebase rules are deployed and try again."); }
  }

  async function submitReference(reference: string) {
    if (!user || !activePayment) return;
    setIsSubmitting(true);
    try {
      await submitPaymentReference(activePayment, { id: user.uid, role: viewerRole }, reference);
      toast.success("Payment received. It is now awaiting verification.");
      setActivePayment(null);
      setPaymentReference("");
    } catch (error) { const code = typeof error === "object" && error && "code" in error ? String(error.code) : ""; toast.error(code.includes("permission-denied") ? "Payment was blocked by the connection record. Refresh this page and try again." : "Your payment could not be recorded. Please check the transaction ID and try again."); }
    finally { setIsSubmitting(false); }
  }

  async function payWithRazorpay() {
    if (!user || !activePayment) return;
    const breakdown = getPaymentBreakdown(activePayment, viewerRole);
    setIsSubmitting(true);
    try {
      await openRazorpayCheckout({
        amount: breakdown.totalAmount,
        name: user.displayName || (viewerRole === "FDE" ? activePayment.fdeName : activePayment.businessName),
        email: user.email || "",
        description: `Adrox connection for ${activePayment.problemTitle}`,
        onSuccess: (paymentId) => { void submitReference(paymentId); },
        onFailure: () => setIsSubmitting(false),
      });
    } catch (error) {
      setIsSubmitting(false);
      toast.error(error instanceof Error ? error.message : "Razorpay checkout could not start.");
    }
  }

  async function sendPayment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (paymentReference.trim().length < 4) return;
    await submitReference(paymentReference.trim());
  }

  async function verifyLocalPayment(connection: ConnectionRecord) {
    setIsSubmitting(true);
    try {
      await mockVerifyLocalPayment(connection.id);
      toast.success("Local mock payment verified. Refreshing the connection state…");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Local mock verification failed.");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function sendReport(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!user || !activeReport) return;
    setIsSubmitting(true);
    try { await submitConnectionReport(activeReport, { id: user.uid, role: viewerRole }, reportDetail); toast.success("Your report has been sent to the administrator for review."); setActiveReport(null); setReportDetail(""); }
    catch { toast.error("Your report could not be submitted. Please check Firebase setup and try again."); }
    finally { setIsSubmitting(false); }
  }

  return <section className="connection-desk">
    <div className="workspace__section-head"><div><span className="eyebrow"><span />{viewerRole === "FDE" ? "Business invitations" : "Secure connections"}</span><h2>{viewerRole === "FDE" ? <>Businesses that<br /><em>asked for you.</em></> : <>Accepted engineers.<br /><em>Next secure step.</em></>}</h2></div><span className="workspace__count">{connections.length.toString().padStart(2, "0")} active</span></div>
    {connections.length === 0 ? <div className="workspace-empty"><ShieldCheck size={27} /><h3>{viewerRole === "FDE" ? "Your invitation desk is ready." : "Your connection desk is ready."}</h3><p>{viewerRole === "FDE" ? "When a Business accepts your proposal, its invitation and fee step will appear here." : "When you accept an FDE proposal, the connection and fee steps will appear here."}</p></div> : <div className="connection-desk__list">{connections.map((connection) => {
      const ownStatus = viewerRole === "BUSINESS" ? connection.businessPaymentStatus : connection.fdePaymentStatus;
      const counterpartStatus = viewerRole === "BUSINESS" ? connection.fdePaymentStatus : connection.businessPaymentStatus;
      const ownFee = viewerRole === "BUSINESS" ? (connection.businessFeeAmount ?? connection.businessFee) : (connection.fdeFeeAmount ?? connection.fdeFee);
      const counterpartFee = viewerRole === "BUSINESS" ? (connection.fdeFeeAmount ?? connection.fdeFee) : (connection.businessFeeAmount ?? connection.businessFee);
      const counterpartLabel = viewerRole === "BUSINESS" ? "FDE" : "Business";
      const contactToShow = viewerRole === "BUSINESS" ? connection.fdeContact : connection.businessContact;
      return <article className="connection-card" key={connection.id}>
        <div className="connection-card__top"><span>{connection.status === "connected" ? "Contact unlocked" : "Connection fee stage"}</span><span>{connection.problemTitle}</span></div>
        <h3>{viewerRole === "BUSINESS" ? connection.fdeName : connection.businessName}</h3>
        <div className="connection-card__fees"><div><span>Your payment</span><strong>{formatConnectionFee(ownFee)}</strong><small className={ownStatus === "verified" ? "fee-status fee-status--verified" : "fee-status"}>{paymentLabel(ownStatus)}</small></div><div><span>{counterpartLabel} payment</span><strong>{formatConnectionFee(counterpartFee)}</strong><small className={counterpartStatus === "verified" ? "fee-status fee-status--verified" : "fee-status"}>{paymentLabel(counterpartStatus)}</small></div></div>
        {ownStatus === "awaiting_payment" && <button className="button button--dark connection-card__pay" type="button" onClick={() => setActivePayment(connection)}>Pay {formatConnectionFee(ownFee)} <Send size={15} /></button>}
        {ownStatus === "submitted" && <><p className="connection-card__pending"><CheckCircle2 size={15} />Payment submitted. Awaiting Admin verification.</p>{isFirebaseEmulatorMode && <button className="connection-card__mock" type="button" onClick={() => verifyLocalPayment(connection)} disabled={isSubmitting}>Mock verify locally</button>}</>}
        {ownStatus === "verified" && counterpartStatus === "submitted" && <p className="connection-card__pending"><CheckCircle2 size={15} />Your payment is verified. Waiting for the other payment to be verified.</p>}
        {connection.contactUnlocked && contactToShow ? <div className="unlocked-contact"><span><ShieldCheck size={15} /> Contact unlocked</span><a href={`mailto:${contactToShow.email}`}><Mail size={14} /> {contactToShow.email}</a>{contactToShow.phone && <span><Phone size={14} /> {contactToShow.phone}</span>}{contactToShow.whatsapp && <span><Smartphone size={14} /> WhatsApp: {contactToShow.whatsapp}</span>}</div> : <div className="locked-contact"><LockKeyhole size={17} /><div><strong>Contact details locked</strong><span>Both payments must be verified before contact details are revealed.</span></div></div>}
        <button className="connection-card__report" type="button" onClick={() => setActiveReport(connection)}><Flag size={13} /> Report a connection issue</button>
      </article>;
    })}</div>}
    <form className="contact-card" onSubmit={saveContact}><div><span className="eyebrow"><span />Private contact card</span><h3>Keep the eventual<br /><em>handshake current.</em></h3><p>Only a confirmed connection receives these details after both payments are verified.</p></div><div className="contact-card__fields"><label>Email<input type="email" value={contact.email} onChange={(event) => setContact((current) => ({ ...current, email: event.target.value }))} required /></label><label>Phone<input value={contact.phone} onChange={(event) => setContact((current) => ({ ...current, phone: event.target.value }))} placeholder="Optional" /></label><label>WhatsApp<input value={contact.whatsapp} onChange={(event) => setContact((current) => ({ ...current, whatsapp: event.target.value }))} placeholder="Optional" /></label><button className="button" type="submit">Save contact card <ShieldCheck size={15} /></button></div></form>
    {activePayment && <div className="payment-drawer" role="dialog" aria-modal="true" aria-labelledby="payment-title"><button className="payment-drawer__backdrop" type="button" onClick={() => setActivePayment(null)} aria-label="Close payment form" /><div className="payment-drawer__panel"><button type="button" className="auth-dialog__close" onClick={() => setActivePayment(null)} aria-label="Close payment form"><X size={20} /></button><span className="eyebrow eyebrow--light"><span />Razorpay connection checkout</span><h2 id="payment-title">Pay the secure<br /><em>connection fee.</em></h2>{(() => { const breakdown = getPaymentBreakdown(activePayment, viewerRole); return <div className="payment-breakdown"><div><span>Project amount</span><strong>{formatConnectionFee(breakdown.baseAmount)}</strong></div><div><span>Adrox slab fee <small>{getFeeSlabLabel(breakdown.baseAmount)}</small></span><strong>+ {formatConnectionFee(breakdown.feeAmount)}</strong></div><div className="payment-breakdown__total"><span>Connection fee payable</span><strong>{formatConnectionFee(breakdown.totalAmount)}</strong></div></div>; })()}<p>The project amount is shown for slab selection only. You pay only the connection fee: a {formatConnectionFee(57000)} project falls in the {formatConnectionFee(50000)}–{formatConnectionFee(100000)} slab, so the payable connection fee is {formatConnectionFee(5000)}.</p><div className="upi-payment-box"><div><span className="eyebrow eyebrow--light"><span />Pay by UPI</span><h3>{activePayment.payeeName || "Adrox"}</h3>{activePayment.upiId ? <strong>{activePayment.upiId}</strong> : <strong>UPI details will be added by Admin</strong>}<p>{activePayment.paymentInstructions || "Pay the exact total, then submit your transaction ID below."}</p>{activePayment.upiId && <a className="button payment-drawer__submit" href={`upi://pay?pa=${encodeURIComponent(activePayment.upiId)}&pn=${encodeURIComponent(activePayment.payeeName || "Adrox")}&am=${getPaymentBreakdown(activePayment, viewerRole).totalAmount}&cu=INR`}>Open UPI app <Send size={15} /></a>}</div>{activePayment.qrImageUrl ? <img src={activePayment.qrImageUrl} alt="UPI payment QR code" /> : <div className="upi-payment-box__placeholder">Admin QR<br />coming soon</div>}</div><button className="button payment-drawer__submit" type="button" onClick={payWithRazorpay} disabled={isSubmitting}>{isSubmitting ? "Opening checkout…" : "Pay securely with Razorpay"} <Send size={16} /></button><div className="payment-drawer__divider"><span>or record an existing payment</span></div><form onSubmit={sendPayment}><label>Transaction / payment reference<input value={paymentReference} onChange={(event) => setPaymentReference(event.target.value)} placeholder="e.g. UTR or payment ID" minLength={4} required /></label><button className="button payment-drawer__submit" type="submit" disabled={isSubmitting}>{isSubmitting ? "Submitting…" : "Submit payment reference"} <Send size={16} /></button></form></div></div>}
    {activeReport && <div className="payment-drawer" role="dialog" aria-modal="true" aria-labelledby="report-title"><button className="payment-drawer__backdrop" type="button" onClick={() => setActiveReport(null)} aria-label="Close report form" /><div className="payment-drawer__panel"><button type="button" className="auth-dialog__close" onClick={() => setActiveReport(null)} aria-label="Close report form"><X size={20} /></button><span className="eyebrow eyebrow--light"><span />Platform safety</span><h2 id="report-title">Put the issue<br /><em>on the record.</em></h2><p>Your report will be visible only to the administrator and to you. It does not reveal private contact details.</p><form onSubmit={sendReport}><label>What needs review?<textarea value={reportDetail} onChange={(event) => setReportDetail(event.target.value)} placeholder="Describe the issue with this connection." minLength={20} required /></label><button className="button payment-drawer__submit" type="submit" disabled={isSubmitting}>{isSubmitting ? "Sending…" : "Send report"} <Flag size={16} /></button></form></div></div>}
  </section>;
}
