/**
 * Design direction: The Signal Room — a sparse operational workspace that extends
 * the midnight ink, Signal Orange, and field-guide pacing from the public site.
 */
import { ArrowUpRight, LogOut } from "lucide-react";
import { Link } from "wouter";
import { logoutAccount } from "@/lib/auth";

const markImage = "/assets/adrox-logo.png";

interface WorkspaceShellProps {
  roleLabel: string;
  title: React.ReactNode;
  description: string;
  active: "business" | "fde" | "admin";
  children: React.ReactNode;
}

export default function WorkspaceShell({ roleLabel, title, description, active, children }: WorkspaceShellProps) {
  async function handleLogout() {
    await logoutAccount();
    window.location.href = "/";
  }

  return (
    <div className="workspace">
      <header className="workspace__header">
        <Link href="/" className="workspace__brand"><img className="brand__logo" src={markImage} alt="Adrox" /></Link>
        <div className="workspace__role">{roleLabel}</div>
        <button className="workspace__logout" type="button" onClick={handleLogout}>Log out <LogOut size={15} /></button>
      </header>
      <div className="workspace__rail"><Link className={active === "business" ? "workspace__rail-link workspace__rail-link--active" : "workspace__rail-link"} href="/business">Business space <ArrowUpRight size={14} /></Link><Link className={active === "fde" ? "workspace__rail-link workspace__rail-link--active" : "workspace__rail-link"} href="/fde">FDE space <ArrowUpRight size={14} /></Link>{active === "admin" && <Link className="workspace__rail-link workspace__rail-link--active" href="/admin">Admin control <ArrowUpRight size={14} /></Link>}</div>
      <main className="workspace__main">
        <p className="eyebrow"><span />{roleLabel}</p>
        <div className="workspace__title-row"><div><h1>{title}</h1><p>{description}</p></div></div>
        {children}
      </main>
    </div>
  );
}
