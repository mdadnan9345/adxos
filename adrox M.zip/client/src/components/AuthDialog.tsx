/**
 * Design direction: The Signal Room — a focused, high-contrast entry panel
 * that keeps the marketplace's editorial confidence inside a functional auth flow.
 */
import { ArrowRight, X } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { activateDesignatedAdministrator, loginAccount, readableAuthError, redirectPathForUser, registerAccount, type RequestedRole } from "@/lib/auth";
import { useLocation } from "wouter";

type AuthMode = "login" | "register";

interface AuthDialogProps {
  open: boolean;
  initialMode: AuthMode;
  onOpenChange: (open: boolean) => void;
}

export default function AuthDialog({ open, initialMode, onOpenChange }: AuthDialogProps) {
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [requestedRole, setRequestedRole] = useState<RequestedRole>("BUSINESS");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (open) setMode(initialMode);
  }, [initialMode, open]);

  if (!open) return null;

  const isRegistration = mode === "register";

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsSubmitting(true);

    try {
      if (isRegistration) {
        const credential = await registerAccount({ name, email, password, requestedRole });
        toast.success("Your Adrox account is ready. Complete your profile to continue.");
        setLocation(await redirectPathForUser(credential.user.uid, requestedRole));
      } else {
        const credential = await loginAccount(email, password);
        const isDesignatedAdministrator = email.trim().toLowerCase() === "mdadnan018863@gmail.com";
        let destination = "/";
        if (isDesignatedAdministrator) {
          try {
            await activateDesignatedAdministrator();
            destination = "/admin";
          } catch (bootstrapError) {
            const refreshedToken = await credential.user.getIdTokenResult(true);
            if (refreshedToken.claims.admin === true && refreshedToken.claims.role === "ADMIN") {
              destination = "/admin";
            } else {
            const errorCode = typeof bootstrapError === "object" && bootstrapError && "code" in bootstrapError ? String(bootstrapError.code) : "";
            toast.error(errorCode.includes("not-found") || errorCode.includes("functions") ? "Admin activation is not deployed yet. Deploy the Firebase Functions, then sign in again." : "Your password is correct, but the Firebase ADMIN claim is not active yet. Deploy the trusted admin function, then sign in again.");
            return;
            }
          }
        } else {
          destination = await redirectPathForUser(credential.user.uid);
        }
        toast.success("Welcome back to Adrox.");
        setLocation(destination);
      }
      onOpenChange(false);
    } catch (error) {
      toast.error(readableAuthError(error));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="auth-dialog" role="dialog" aria-modal="true" aria-labelledby="auth-dialog-title">
      <button className="auth-dialog__backdrop" type="button" aria-label="Close authentication dialog" onClick={() => onOpenChange(false)} />
      <div className="auth-dialog__panel">
        <button className="auth-dialog__close" type="button" aria-label="Close" onClick={() => onOpenChange(false)}><X size={20} /></button>
        <p className="eyebrow eyebrow--light"><span />Secure access</p>
        <h2 id="auth-dialog-title">{isRegistration ? <>Start with <em>intent.</em></> : <>Welcome <em>back.</em></>}</h2>
        <p className="auth-dialog__lede">{isRegistration ? "Choose how you will participate. Your role is confirmed by secure server-side rules after registration." : "Use your Adrox email and password to continue."}</p>
        <form className="auth-form" onSubmit={handleSubmit}>
          {isRegistration && <label>Full name<input value={name} onChange={(event) => setName(event.target.value)} placeholder="Your full name" autoComplete="name" required /></label>}
          <label>Email address<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="name@company.com" autoComplete="email" required /></label>
          <label>Password<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 6 characters" autoComplete={isRegistration ? "new-password" : "current-password"} minLength={6} required /></label>
          {isRegistration && <fieldset><legend>I am joining as</legend><div className="auth-role-options"><label className={requestedRole === "BUSINESS" ? "auth-role auth-role--selected" : "auth-role"}><input type="radio" name="account-role" checked={requestedRole === "BUSINESS"} onChange={() => setRequestedRole("BUSINESS")} />Business / entrepreneur</label><label className={requestedRole === "FDE" ? "auth-role auth-role--selected" : "auth-role"}><input type="radio" name="account-role" checked={requestedRole === "FDE"} onChange={() => setRequestedRole("FDE")} />Forward Deployed Engineer</label></div></fieldset>}
          <button className="button auth-form__submit" type="submit" disabled={isSubmitting}>{isSubmitting ? "Working…" : isRegistration ? "Create secure account" : "Log in"}<ArrowRight size={16} /></button>
        </form>
        <p className="auth-dialog__switch">{isRegistration ? "Already have an account?" : "New to Adrox?"} <button type="button" onClick={() => setMode(isRegistration ? "login" : "register")}>{isRegistration ? "Log in" : "Join now"}</button></p>
      </div>
    </div>
  );
}
