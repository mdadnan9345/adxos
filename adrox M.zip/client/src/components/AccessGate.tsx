/**
 * Design direction: The Signal Room — an honest, direct access state that never
 * disguises missing Firebase role configuration as successful authorisation.
 */
import { ArrowRight, ShieldAlert } from "lucide-react";
import { Link } from "wouter";
import { useAdroxSession } from "@/hooks/useAdroxSession";
import type { AccountRole } from "@/lib/account";

export default function AccessGate({ requiredRole, children }: { requiredRole: AccountRole; children: React.ReactNode }) {
  const { user, role, isLoading } = useAdroxSession();
  const isBusinessRoute = requiredRole === "BUSINESS";
  const isAdminRoute = requiredRole === "ADMIN";
  const routeEyebrow = isAdminRoute ? "Administrator control room" : isBusinessRoute ? "Business problem desk" : "Forward Deployed Engineer field guide";
  const routeTitle = isAdminRoute ? <>Keep the signal<br /><em>in good order.</em></> : isBusinessRoute ? <>Bring the constraint<br /><em>into focus.</em></> : <>Follow the signal<br /><em>to useful work.</em></>;
  const routeDescription = isAdminRoute ? "Sign in with the verified Adrox administrator account to review people, payments, connections, platform safety, and dispute records." : isBusinessRoute ? "Sign in to write a real operating problem, find the right engineer, and keep contact private until both sides are ready." : "Sign in to examine the latest published constraints, follow the working context, and decide where your craft can move the work forward.";
  const moduleLabel = isAdminRoute ? "Control sequence" : isBusinessRoute ? "Problem sequence" : "Field sequence";
  const moduleSteps = isAdminRoute ? ["Review a payment", "Verify the release"] : isBusinessRoute ? ["Frame the work", "Choose the right handoff"] : ["Read the operating signal", "Send an informed approach"];

  if (isLoading) return <div className="access-state"><span className="access-state__pulse" />Checking your secure workspace…</div>;
  if (!user) return <div className={isAdminRoute ? "access-state access-state--admin" : isBusinessRoute ? "access-state access-state--business" : "access-state access-state--fde"}><div className="access-state__canvas"><div className="access-state__artifact"><span>01</span><i /><span>Signal path</span></div><div className="access-state__route"><span className="eyebrow eyebrow--light"><span />{routeEyebrow}</span><ShieldAlert size={25} /><h1>{routeTitle}</h1><p>{routeDescription}</p><Link className="button button--dark" href="/">Return to Adrox <ArrowRight size={16} /></Link></div><aside className="access-state__ledger"><span>{moduleLabel}</span><ol>{moduleSteps.map((step, index) => <li key={step}><b>0{index + 1}</b>{step}</li>)}</ol></aside></div></div>;
  if (role === requiredRole || role === "ADMIN") return <>{children}</>;
  if (!role) return <div className="access-state"><ShieldAlert size={25} /><h1>Role setup is still pending.</h1><p>Your Firebase account is active, but its workspace role is not available yet. Sign out and back in after the Firebase rules and role function are deployed.</p><Link className="button button--dark" href="/">Return to Adrox <ArrowRight size={16} /></Link></div>;

  const roleName = requiredRole === "BUSINESS" ? "Business" : "Forward Deployed Engineer";
  return <div className="access-state"><ShieldAlert size={25} /><h1>This is the {roleName} space.</h1><p>Your account is registered as {role === "FDE" ? "a Forward Deployed Engineer" : "a Business / entrepreneur"}. Use the workspace that matches your secure account type.</p><Link className="button button--dark" href={role === "FDE" ? "/fde" : "/business"}>Open my workspace <ArrowRight size={16} /></Link></div>;
}
