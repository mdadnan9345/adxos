/**
 * Design direction: The Signal Room — a focused FDE field guide where clear,
 * published business constraints are the priority, not a generic job-board feed.
 */
import { ArrowUpRight, CheckCircle2, Filter, MapPin, SearchX, Send, Sparkles, X } from "lucide-react";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { toast } from "sonner";
import AccessGate from "@/components/AccessGate";
import WorkspaceShell from "@/components/WorkspaceShell";
import { useAdroxSession } from "@/hooks/useAdroxSession";
import { formatBudget, formatPostedDate, subscribeToPublishedProblems, type ProblemRecord } from "@/lib/problems";
import { subscribeToFdeProfile, updateFdeDirectoryRecord, type FdeDirectoryRecord } from "@/lib/fdes";
import { formatProposedBudget, submitProposal, subscribeToFdeProposals, type ProposalInput, type ProposalRecord } from "@/lib/proposals";
import ConnectionDesk from "@/components/ConnectionDesk";

const blankProposal: ProposalInput = { approach: "", deliveryWindow: "", proposedBudget: 75000 };
const blankFdeProfile: Pick<FdeDirectoryRecord, "fullName" | "professionalTitle" | "location" | "availability"> = { fullName: "", professionalTitle: "Forward Deployed Engineer", location: "", availability: "Available for conversations" };

function FdeWorkspace() {
  const { user } = useAdroxSession();
  const [problems, setProblems] = useState<ProblemRecord[]>([]);
  const [proposals, setProposals] = useState<ProposalRecord[]>([]);
  const [filter, setFilter] = useState("");
  const [industry, setIndustry] = useState("All industries");
  const [selectedProblem, setSelectedProblem] = useState<ProblemRecord | null>(null);
  const [proposal, setProposal] = useState<ProposalInput>(blankProposal);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [profile, setProfile] = useState(blankFdeProfile);
  const [isProfileSaving, setIsProfileSaving] = useState(false);

  useEffect(() => subscribeToPublishedProblems(setProblems, () => toast.error("The problem feed is unavailable until Firebase rules are deployed.")), []);
  useEffect(() => {
    if (!user) return;
    return subscribeToFdeProposals(user.uid, setProposals, () => toast.error("Your proposal history is unavailable until Firebase rules are deployed."));
  }, [user]);
  useEffect(() => {
    if (!user) return;
    return subscribeToFdeProfile(user.uid, (nextProfile) => setProfile(nextProfile ? {
      fullName: nextProfile.fullName,
      professionalTitle: nextProfile.professionalTitle,
      location: nextProfile.location,
      availability: nextProfile.availability,
    } : { ...blankFdeProfile, fullName: user.displayName || "" }), () => toast.error("Your public FDE profile could not be loaded."));
  }, [user]);

  const industries = useMemo(() => ["All industries", ...Array.from(new Set(problems.map((problem) => problem.industry))).sort()], [problems]);
  const matchingProblems = useMemo(() => problems.filter((problem) => {
    const content = `${problem.title} ${problem.industry} ${problem.location} ${problem.currentProcess} ${problem.expectedOutcome}`.toLowerCase();
    return (industry === "All industries" || problem.industry === industry) && content.includes(filter.trim().toLowerCase());
  }), [filter, industry, problems]);

  const submittedProblemIds = useMemo(() => new Set(proposals.map((proposalItem) => proposalItem.problemId)), [proposals]);

  function openProposal(problem: ProblemRecord) {
    setSelectedProblem(problem);
    setProposal({ ...blankProposal, proposedBudget: Math.round((problem.budgetMin + problem.budgetMax) / 2) });
  }

  async function handleProposalSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedProblem || !user) return;
    setIsSubmitting(true);
    try {
      await submitProposal(proposal, {
        problemId: selectedProblem.id,
        problemTitle: selectedProblem.title,
        businessId: selectedProblem.businessId,
        businessName: selectedProblem.businessName,
        fdeId: user.uid,
        fdeName: user.displayName || user.email?.split("@")[0] || "Forward Deployed Engineer",
      });
      toast.success("Your proposal and connection request have been sent to the Business.");
      setSelectedProblem(null);
      setProposal(blankProposal);
    } catch {
      toast.error("Your proposal could not be sent. Confirm the Firebase rules are deployed and try again.");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleProfileSave(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!user) return;
    setIsProfileSaving(true);
    try {
      await updateFdeDirectoryRecord(user.uid, profile);
      toast.success("Your public FDE profile has been updated.");
    } catch {
      toast.error("Your public profile could not be updated. Confirm Firebase rules are deployed and try again.");
    } finally {
      setIsProfileSaving(false);
    }
  }

  return <WorkspaceShell active="fde" roleLabel="Forward Deployed Engineer" title={<>Find the work<br /><em>worth solving.</em></>} description="Every published Business problem appears here. Read the operating context first, then decide where your expertise can make the most useful difference.">
    <section className="workspace__callout workspace__callout--fde"><div><span className="workspace__callout-kicker">Live business problems</span><h2>Real constraints. Practical scope.</h2><p>Search by industry, location, or the problem itself. The feed only includes problems a Business has chosen to publish.</p></div><div className="workspace__signal"><Sparkles size={19} /><span>{problems.length} published</span></div></section>
    <section className="fde-profile-card"><div><span className="eyebrow eyebrow--light"><span />Public FDE profile</span><h2>Give businesses<br /><em>useful signal.</em></h2><p>This is the professional information a Business sees before deciding whether to respond to your proposal. Private contact details remain locked.</p></div><form onSubmit={handleProfileSave} className="fde-profile-form"><label>Full name<input value={profile.fullName} onChange={(event) => setProfile((current) => ({ ...current, fullName: event.target.value }))} required minLength={2} /></label><label>Professional title<input value={profile.professionalTitle} onChange={(event) => setProfile((current) => ({ ...current, professionalTitle: event.target.value }))} required minLength={3} /></label><label>Location<input value={profile.location} onChange={(event) => setProfile((current) => ({ ...current, location: event.target.value }))} placeholder="e.g. Bengaluru · Remote" required /></label><label>Availability<input value={profile.availability} onChange={(event) => setProfile((current) => ({ ...current, availability: event.target.value }))} placeholder="e.g. Available from October" required /></label><button className="button" type="submit" disabled={isProfileSaving}>{isProfileSaving ? "Saving…" : "Save public profile"} <CheckCircle2 size={15} /></button></form></section>
    <ConnectionDesk viewerRole="FDE" />
    <section className="feed-tools" aria-label="Problem filters"><label><span>Search problems</span><input value={filter} onChange={(event) => setFilter(event.target.value)} placeholder="Try reporting, retail, automation…" /></label><label><span>Industry</span><select value={industry} onChange={(event) => setIndustry(event.target.value)}>{industries.map((option) => <option key={option}>{option}</option>)}</select></label><div className="feed-tools__filter"><Filter size={16} /> Active filters: {industry === "All industries" && !filter ? "none" : "applied"}</div></section>
    {proposals.length > 0 && <section className="proposal-history"><div className="workspace__section-head"><div><span className="eyebrow"><span />Your proposals</span><h2>Signals already<br /><em>in motion.</em></h2></div><span className="workspace__count">{proposals.length.toString().padStart(2, "0")} sent</span></div><div className="proposal-history__list">{proposals.map((proposalItem) => <article className="proposal-history__item" key={proposalItem.id}><div><span className={proposalItem.status === "accepted" ? "proposal-history__status proposal-history__status--accepted" : "proposal-history__status"}>{proposalItem.status === "submitted" ? "Awaiting Business" : proposalItem.status}</span><h3>{proposalItem.problemTitle}</h3><p>To {proposalItem.businessName} · {proposalItem.deliveryWindow} · {formatProposedBudget(proposalItem.proposedBudget)}</p></div>{proposalItem.businessResponse && <div className="proposal-history__response"><CheckCircle2 size={15} />{proposalItem.businessResponse}</div>}</article>)}</div></section>}
    <section className="workspace__section"><div className="workspace__section-head"><div><span className="eyebrow"><span />Problem feed</span><h2>Business problems in view.</h2></div><span className="workspace__count">{matchingProblems.length.toString().padStart(2, "0")} matched</span></div>{matchingProblems.length === 0 ? <div className="workspace-empty"><SearchX size={27} /><h3>No published problems match yet.</h3><p>Clear your filters or come back as businesses publish new, concrete work.</p></div> : <div className="fde-feed">{matchingProblems.map((problem) => { const alreadySubmitted = submittedProblemIds.has(problem.id); return <article className="fde-problem" key={problem.id}><div className="fde-problem__meta"><span>{problem.industry}</span><span>Published {formatPostedDate(problem)}</span></div><div className="fde-problem__title"><h3>{problem.title}</h3><ArrowUpRight size={21} /></div><p>{problem.currentProcess}</p><div className="fde-problem__outcome"><strong>Expected outcome</strong><span>{problem.expectedOutcome}</span></div><footer><span><MapPin size={14} /> {problem.location} · {problem.workMode}</span><strong>{formatBudget(problem)}</strong><button className={alreadySubmitted ? "proposal-button proposal-button--submitted" : "proposal-button"} type="button" disabled={alreadySubmitted} onClick={() => openProposal(problem)}>{alreadySubmitted ? <>Request sent <CheckCircle2 size={14} /></> : <>Send proposal <Send size={14} /></>}</button></footer></article>; })}</div>}</section>
    {selectedProblem && <section className="proposal-drawer" role="dialog" aria-modal="true" aria-labelledby="proposal-title"><button type="button" className="proposal-drawer__backdrop" aria-label="Close proposal form" onClick={() => setSelectedProblem(null)} /><div className="proposal-drawer__panel"><div className="proposal-drawer__head"><div><span className="eyebrow eyebrow--light"><span />Proposal & connection request</span><h2 id="proposal-title">{selectedProblem.title}</h2><p>Send an informed approach. The Business receives this securely; your private contact details remain protected.</p></div><button type="button" className="auth-dialog__close" onClick={() => setSelectedProblem(null)} aria-label="Close proposal form"><X size={20} /></button></div><form className="proposal-form" onSubmit={handleProposalSubmit}><label>Your approach<textarea value={proposal.approach} onChange={(event) => setProposal((current) => ({ ...current, approach: event.target.value }))} placeholder="Explain how you would investigate, shape, and deliver this work." minLength={30} required /></label><div className="proposal-form__grid"><label>Delivery window<input value={proposal.deliveryWindow} onChange={(event) => setProposal((current) => ({ ...current, deliveryWindow: event.target.value }))} placeholder="e.g. 4–6 weeks" minLength={3} required /></label><label>Proposed budget (₹)<input type="number" min="0" step="1000" value={proposal.proposedBudget} onChange={(event) => setProposal((current) => ({ ...current, proposedBudget: Number(event.target.value) }))} required /></label></div><div className="proposal-form__note"><CheckCircle2 size={16} /><span>Submitting sends a connection request to <strong>{selectedProblem.businessName}</strong>. No direct contact information is revealed at this stage.</span></div><button className="button proposal-form__submit" type="submit" disabled={isSubmitting}>{isSubmitting ? "Sending…" : "Send proposal & request"} <Send size={16} /></button></form></div></section>}
  </WorkspaceShell>;
}

export default function FdeDashboard() {
  return <AccessGate requiredRole="FDE"><FdeWorkspace /></AccessGate>;
}
