/**
 * Design direction: The Signal Room — editorial product design with midnight ink,
 * chalky paper surfaces, Signal Orange actions, and deliberately asymmetric rhythm.
 */
import {
  ArrowDownRight,
  ArrowRight,
  BadgeCheck,
  BriefcaseBusiness,
  ChevronRight,
  CircleCheck,
  CircleDashed,
  Clock3,
  LockKeyhole,
  MapPin,
  Menu,
  Network,
  Search,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import { useState } from "react";
import AuthDialog from "@/components/AuthDialog";
import { CONNECTION_FEE_SLABS, formatINR } from "@/lib/fees";

const heroImage = "/assets/hero-grounded-operations.webp";
const flowImage = "/assets/problem-flow.webp";
const portraitImage = "/assets/engineer-portrait.webp";
const markImage = "/assets/adrox-logo.png";

const problems = [
  {
    category: "Healthcare operations",
    title: "Reduce manual hospital reporting by 70%",
    description: "Turn spreadsheet and WhatsApp reporting into a reliable central workflow.",
    budget: "₹50k–₹1L",
    place: "Kolkata · Hybrid",
    interest: "12 FDEs exploring",
  },
  {
    category: "Retail systems",
    title: "See inventory signals before stockouts happen",
    description: "Connect fragmented store data to make replenishment decisions less reactive.",
    budget: "₹75k–₹1.5L",
    place: "Bengaluru · Remote",
    interest: "8 FDEs exploring",
  },
  {
    category: "Field operations",
    title: "Make service dispatch visible in real time",
    description: "Give a growing maintenance team a practical way to manage work in motion.",
    budget: "₹40k–₹80k",
    place: "Pune · On site",
    interest: "16 FDEs exploring",
  },
];

const capabilities = [
  { initials: "AR", title: "Automation systems", tags: ["Python", "Workflow design", "APIs"] },
  { initials: "KM", title: "Data & decision tools", tags: ["Analytics", "BI", "Operations"] },
  { initials: "SP", title: "Product engineering", tags: ["Full stack", "MVPs", "Integrations"] },
];

function SectionEyebrow({ children, light = false }: { children: React.ReactNode; light?: boolean }) {
  return (
    <p className={`eyebrow ${light ? "eyebrow--light" : ""}`}>
      <span />
      {children}
    </p>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register">("register");

  const closeMenu = () => setMenuOpen(false);
  const openAuth = (mode: "login" | "register") => {
    setAuthMode(mode);
    setAuthDialogOpen(true);
    closeMenu();
  };

  return (
    <div className="site-shell">
      <header className="site-header">
        <a className="brand" href="#top" aria-label="Adrox home" onClick={closeMenu}>
          <img className="brand__logo" src={markImage} alt="Adrox" />
        </a>

        <nav className="desktop-nav" aria-label="Primary navigation">
          <a href="#how-it-works">How it works</a>
          <a href="#problems">Explore problems</a>
          <a href="#engineers">Find FDEs</a>
          <a href="#pricing">Pricing</a>
        </nav>

        <div className="header-actions">
          <button className="login-link" type="button" onClick={() => openAuth("login")}>Log in</button>
          <button className="button button--small" type="button" onClick={() => openAuth("register")}>Join Adrox <ArrowRight size={15} /></button>
          <button className="mobile-toggle" type="button" onClick={() => setMenuOpen((value) => !value)} aria-expanded={menuOpen} aria-controls="mobile-menu" aria-label="Toggle navigation">
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        <div className={`mobile-menu ${menuOpen ? "mobile-menu--open" : ""}`} id="mobile-menu">
          <a href="#how-it-works" onClick={closeMenu}>How it works</a>
          <a href="#problems" onClick={closeMenu}>Explore problems</a>
          <a href="#engineers" onClick={closeMenu}>Find FDEs</a>
          <a href="#pricing" onClick={closeMenu}>Pricing</a>
          <button className="button" type="button" onClick={() => openAuth("register")}>Join Adrox <ArrowRight size={16} /></button>
        </div>
      </header>

      <main id="top">
        <section className="hero section-ink">
          <div className="hero__grain" aria-hidden="true" />
          <div className="hero__copy rise-in">
            <SectionEyebrow light>Built for work that matters</SectionEyebrow>
            <h1>Real problems.<br /><em>Real engineers.</em><br />Real solutions.</h1>
            <p className="hero__lede">Businesses bring the operational challenges that cannot wait. Forward Deployed Engineers discover, understand, and design the way through.</p>
            <div className="hero__actions">
              <button className="button" type="button" onClick={() => openAuth("register")}>Post a problem <ArrowDownRight size={17} /></button>
              <button className="text-link text-link--light" type="button" onClick={() => openAuth("register")}>Find an FDE <ArrowRight size={16} /></button>
            </div>
          </div>

          <div className="hero__visual rise-in rise-in--late">
            <div className="hero__visual-frame">
              <img src={heroImage} alt="An engineer and business owner working through a solution together" />
              <div className="hero__image-overlay" />
            </div>
            <div className="hero__problem-note">
              <span className="note-dot" />
              <div><small>Today’s signal</small><strong>Problems deserve builders, not browser tabs.</strong></div>
            </div>
          </div>

          <div className="hero__ticker" aria-label="Adrox values">
            <span>Business constraints</span><i />
            <span>Engineering clarity</span><i />
            <span>Verified connections</span><i />
          </div>
        </section>

        <section className="intro-band">
          <div className="intro-band__title">
            <SectionEyebrow>A marketplace, not a job board</SectionEyebrow>
            <h2>Bring the <em>actual work.</em></h2>
          </div>
          <p>Adrox connects businesses with Forward Deployed Engineers who are ready to understand a real operating environment, propose a practical path forward, and make meaningful change happen.</p>
          <a className="round-link" href="#how-it-works" aria-label="See how Adrox works"><ArrowDownRight size={24} /></a>
        </section>

        <section className="how section-paper" id="how-it-works">
          <div className="how__heading">
            <SectionEyebrow>How Adrox works</SectionEyebrow>
            <h2>The work starts<br />with <em>clarity.</em></h2>
          </div>
          <div className="steps-wrap">
            <div className="signal-path" aria-hidden="true"><svg viewBox="0 0 940 195" fill="none"><path d="M4 15C128 14 154 178 315 178c171 0 118-141 288-141 172 0 147 141 333 141" stroke="currentColor" strokeWidth="1.5" strokeDasharray="4 7" /></svg></div>
            <ol className="steps-list">
              <li><span className="step-number">01</span><h3>Frame the problem</h3><p>A business describes what is getting in the way: current process, desired outcome, budget, and context.</p></li>
              <li><span className="step-number">02</span><h3>Meet informed interest</h3><p>FDEs discover the opportunity and send an approach, expected timeline, and proposed budget.</p></li>
              <li><span className="step-number">03</span><h3>Unlock a true connection</h3><p>Once both sides commit to the connection, private contact details are unlocked securely.</p></li>
            </ol>
          </div>
          <div className="how__image-card">
            <div className="image-card__copy"><span>From signal to system</span><p>A better fit starts with an honest brief—not a keyword match.</p></div>
            <img src={flowImage} alt="Abstract visualisation of a business problem becoming a complete solution" />
          </div>
        </section>

        <section className="problems-section section-ink" id="problems">
          <div className="problems-section__head">
            <div>
              <SectionEyebrow light>Explore business problems</SectionEyebrow>
              <h2>Where builders<br /><em>can be useful.</em></h2>
            </div>
            <a className="text-link text-link--light" href="#access">Browse every problem <ArrowRight size={16} /></a>
          </div>
          <div className="problem-list">
            {problems.map((problem, index) => (
              <article className="problem-card" key={problem.title}>
                <div className="problem-card__top"><span className="card-index">0{index + 1}</span><span className="category-label">{problem.category}</span><ArrowUpRightIcon /></div>
                <h3>{problem.title}</h3>
                <p>{problem.description}</p>
                <div className="problem-card__details"><span><MapPin size={14} /> {problem.place}</span><strong>{problem.budget}</strong></div>
                <div className="problem-card__footer"><CircleDashed size={15} /> {problem.interest}</div>
              </article>
            ))}
          </div>
        </section>

        <section className="engineers-section section-paper" id="engineers">
          <div className="engineers-layout">
            <div className="portrait-stack">
              <div className="portrait-frame"><img src={portraitImage} alt="Forward Deployed Engineer reviewing a practical solution" /></div>
              <div className="portrait-stamp"><Sparkles size={17} /><span>Forward<br />deployed</span></div>
            </div>
            <div className="engineers-copy">
              <SectionEyebrow>Find a Forward Deployed Engineer</SectionEyebrow>
              <h2>Not just people<br />who <em>build.</em></h2>
              <p>FDEs are problem-solvers who bridge technology and the way your organisation actually works. They show up ready to investigate, shape, and deliver.</p>
              <button className="button button--dark" type="button" onClick={() => openAuth("register")}>Find an FDE <Search size={16} /></button>
              <div className="capability-stack" aria-label="Sample Forward Deployed Engineer capabilities">
                {capabilities.map((capability) => (
                  <div className="capability" key={capability.initials}>
                    <div className="capability__avatar">{capability.initials}</div>
                    <div><strong>{capability.title}</strong><span>{capability.tags.join(" · ")}</span></div>
                    <ChevronRight size={17} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="connection-section" id="pricing">
          <div className="connection-heading">
            <SectionEyebrow>Connection, with intent</SectionEyebrow>
            <h2>A clear way to<br /><em>say yes.</em></h2>
          </div>
          <div className="connection-card">
            <div className="connection-card__intro"><p>Adrox is not part of the project payment. We charge each side a transparent connection fee only when a working relationship is ready to begin.</p><a className="text-link" href="#access">See connection pricing <ArrowRight size={16} /></a></div>
            <div className="connection-flow" aria-label="Connection unlock process">
              <div className="flow-person"><BriefcaseBusiness size={22} /><span>Business</span><small>connection fee verified</small></div>
              <div className="flow-line"><i /><span>When both sides are ready</span><i /></div>
              <div className="flow-unlock"><LockKeyhole size={24} /><span>Contact<br />unlocked</span></div>
              <div className="flow-line flow-line--right"><i /></div>
              <div className="flow-person"><Network size={22} /><span>FDE</span><small>connection fee verified</small></div>
            </div>
            <div className="fee-schedule"><div><span className="eyebrow"><span />0.5% transparent fee policy</span><h3>Pay the project amount<br /><em>plus the connection slab.</em></h3><p>For example, a ₹57,000 project uses the ₹50,000–₹1,00,000 slab: ₹57,000 + ₹5,000 = ₹62,000 payable.</p></div><div className="fee-schedule__grid">{CONNECTION_FEE_SLABS.map((slab) => <div key={`${slab.minimum}-${slab.maximum}`}><span>{formatINR(slab.minimum)} – {formatINR(slab.maximum)}</span><strong>{formatINR(slab.fee)}</strong></div>)}</div></div>
          </div>
        </section>

        <section className="security-section section-ink">
          <div className="security-section__panel">
            <div>
              <SectionEyebrow light>Trust & security</SectionEyebrow>
              <h2>Private by default.<br /><em>Connected by choice.</em></h2>
            </div>
            <p>Private contact information stays protected until a connection is active. Every relationship begins with consent, clear intent, and verified commitment from both sides.</p>
          </div>
          <div className="security-points">
            <div><ShieldCheck size={22} /><h3>Contact stays locked</h3><p>Private phone, WhatsApp, and email details never appear in public listings.</p></div>
            <div><BadgeCheck size={22} /><h3>Dual verification</h3><p>Both connection fees must be verified before the relationship moves forward.</p></div>
            <div><Clock3 size={22} /><h3>Built for decisions</h3><p>Proposals set out the approach, budget, and timeline before either side connects.</p></div>
          </div>
        </section>

        <section className="final-cta" id="access">
          <div className="final-cta__number">01 / 01</div>
          <div className="final-cta__content">
            <SectionEyebrow>Make the work move</SectionEyebrow>
            <h2>Bring the work<br />that will <em>not wait.</em></h2>
            <p>Whether you are carrying a difficult business constraint or looking for the next meaningful problem to solve, Adrox gives the conversation a starting point.</p>
            <div className="final-cta__buttons"><button className="button button--dark" type="button" onClick={() => openAuth("register")}>Post a problem <ArrowDownRight size={17} /></button><button className="button button--outline" type="button" onClick={() => openAuth("register")}>Join as an FDE <ArrowRight size={17} /></button></div>
          </div>
          <div className="final-cta__orb" aria-hidden="true"><img src={markImage} alt="" /></div>
        </section>
      </main>

      <footer className="site-footer">
        <a className="brand brand--footer" href="#top"><img className="brand__logo" src={markImage} alt="Adrox" /></a>
        <p>Real Problems. Real Engineers. Real Solutions.</p>
        <div className="footer-links"><a href="#how-it-works">How it works</a><a href="#pricing">Pricing</a><a href="mailto:hello@adrox.com">Contact</a></div>
        <small>© {new Date().getFullYear()} Adrox. Built for useful work.</small>
      </footer>
      <AuthDialog open={authDialogOpen} initialMode={authMode} onOpenChange={setAuthDialogOpen} />
    </div>
  );
}

function ArrowUpRightIcon() {
  return <ArrowDownRight className="problem-card__arrow" size={21} strokeWidth={1.7} />;
}
