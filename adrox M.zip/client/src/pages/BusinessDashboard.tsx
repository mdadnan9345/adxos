/**
 * Design direction: The Signal Room — an operational Business workspace with a
 * clear publishing desk, paper-like form surfaces, and real-time problem records.
 */
import { BriefcaseBusiness, CheckCircle2, CircleCheckBig, MapPin, Plus, Send, UserRound, X } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import AccessGate from "@/components/AccessGate";
import WorkspaceShell from "@/components/WorkspaceShell";
import { useAdroxSession } from "@/hooks/useAdroxSession";
import { createProblem, formatBudget, formatPostedDate, subscribeToBusinessProblems, type ProblemInput, type ProblemRecord } from "@/lib/problems";
import { subscribeToFdeDirectory, type FdeDirectoryRecord } from "@/lib/fdes";
import { decideProposal, formatProposedBudget, subscribeToBusinessProposals, type ProposalRecord } from "@/lib/proposals";
import ConnectionDesk from "@/components/ConnectionDesk";

const blankProblem: ProblemInput = { title: "", industry: "", location: "", workMode: "Hybrid", currentProcess: "", expectedOutcome: "", budgetMin: 50000, budgetMax: 100000 };

function BusinessWorkspace() {
  const { user } = useAdroxSession();
  const [problems, setProblems] = useState<ProblemRecord[]>([]);
  const [fdes, setFdes] = useState<FdeDirectoryRecord[]>([]);
  const [proposals, setProposals] = useState<ProposalRecord[]>([]);
  const [isComposerOpen, setIsComposerOpen] = useState(false);
  const [form, setForm] = useState<ProblemInput>(blankProblem);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    return subscribeToBusinessProblems(user.uid, setProblems, () => toast.error("We could not load your problems yet. Please try again after Firebase rules are deployed."));
  }, [user]);

  useEffect(() => subscribeToFdeDirectory(setFdes, () => toast.error("We could not load the FDE directory yet. Please try again after Firebase rules are deployed.")), []);

  useEffect(() => {
    if (!user) return;
    return subscribeToBusinessProposals(user.uid, setProposals, () => toast.error("We could not load incoming proposals yet. Please try again after Firebase rules are deployed."));
  }, [user]);

  async function handleProposalDecision(proposal: ProposalRecord, decision: "accepted" | "declined") {
    try {
      await decideProposal(proposal.id, decision);
      toast.success(decision === "accepted" ? "Request accepted. Opening the payment page now; contact details stay locked until Admin verifies both payments." : "The proposal has been declined.");
    } catch {
      toast.error("We could not update this proposal. Confirm the Firebase rules are deployed and try again.");
    }
  }

  function updateField<Key extends keyof ProblemInput>(key: Key, value: ProblemInput[Key]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!user) return;
    if (form.budgetMax < form.budgetMin) {
      toast.error("The maximum budget must be greater than the minimum budget.");
      return;
    }
    setIsSaving(true);
    try {
      await createProblem(form, { uid: user.uid, businessName: user.displayName || user.email?.split("@")[0] || "Verified business" });
      toast.success("Your problem is live in the FDE space. An administrator can still moderate it.");
      setForm(blankProblem);
      setIsComposerOpen(false);
    } catch {
      toast.error("Your problem could not be published yet. Confirm that the Firebase rules are deployed and try again.");
    } finally {
      setIsSaving(false);
    }
  }

  return <WorkspaceShell active="business" roleLabel="Business / entrepreneur" title={<>Make the work<br /><em>visible.</em></>} description="Write the operational problem in front of you. Once posted, Forward Deployed Engineers can see the brief and respond with an outcome, timeline, and offer.">
    <section className="workspace__callout"><div><span className="workspace__callout-kicker">Your publishing desk</span><h2>One clear brief is enough to start.</h2><p>Describe the current process, the outcome you need, and the budget range. Your problem appears in the FDE space immediately, while the administrator retains moderation control.</p></div><button className="button" type="button" onClick={() => setIsComposerOpen(true)}>Post a problem <Plus size={17} /></button></section>
    <ConnectionDesk viewerRole="BUSINESS" />
    <section className="proposal-inbox"><div className="workspace__section-head"><div><span className="eyebrow"><span />Incoming proposals</span><h2>Engineers who<br /><em>want to help.</em></h2></div><span className="workspace__count">{proposals.filter((proposal) => proposal.status === "submitted").length.toString().padStart(2, "0")} waiting</span></div>{proposals.length === 0 ? <div className="workspace-empty"><CircleCheckBig size={27} /><h3>Your proposal inbox is ready.</h3><p>When an FDE responds to one of your published problems, their approach, timeline, and proposed budget will appear here.</p></div> : <div className="proposal-inbox__list">{proposals.map((proposal) => <article className="proposal-card" key={proposal.id}><div className="proposal-card__meta"><span>{proposal.status === "submitted" ? "Connection request" : proposal.status}</span><span>For: {proposal.problemTitle}</span></div><h3>{proposal.fdeName}</h3><p>{proposal.approach}</p><div className="proposal-card__details"><span><strong>Delivery</strong>{proposal.deliveryWindow}</span><span><strong>Budget</strong>{formatProposedBudget(proposal.proposedBudget)}</span></div>{proposal.status === "submitted" ? <div className="proposal-card__actions"><button type="button" className="button button--small" onClick={() => handleProposalDecision(proposal, "accepted")}>Accept request <CheckCircle2 size={15} /></button><button type="button" className="proposal-card__decline" onClick={() => handleProposalDecision(proposal, "declined")}>Decline</button></div> : <div className={proposal.status === "accepted" ? "proposal-card__result proposal-card__result--accepted" : "proposal-card__result"}><CheckCircle2 size={15} />{proposal.businessResponse}</div>}</article>)}</div>}</section>
    <section className="fde-directory"><div className="fde-directory__head"><div><span className="eyebrow"><span />Registered Forward Deployed Engineers</span><h2>People ready to<br /><em>get useful.</em></h2></div><span className="workspace__count">{fdes.length.toString().padStart(2, "0")} registered</span></div>{fdes.length === 0 ? <div className="workspace-empty"><UserRound size={27} /><h3>The FDE directory is growing.</h3><p>Registered Forward Deployed Engineers will appear here as they join Adrox. Their contact details stay private until a secure connection becomes active.</p></div> : <div className="fde-directory__grid">{fdes.map((fde) => <article className="fde-card" key={fde.id}><div className="fde-card__monogram">{fde.fullName.split(" ").map((part) => part[0]).join("").slice(0, 2).toUpperCase()}</div><div><span>{fde.availability}</span><h3>{fde.fullName}</h3><p>{fde.professionalTitle}</p><small><MapPin size={13} /> {fde.location}</small></div></article>)}</div>}</section>
    {isComposerOpen && <section className="problem-composer"><div className="problem-composer__head"><div><span className="eyebrow"><span />New business problem</span><h2>Frame the work.</h2></div><button type="button" className="plain-icon" onClick={() => setIsComposerOpen(false)} aria-label="Close problem form"><X size={20} /></button></div><form onSubmit={handleSubmit} className="problem-form"><label>Problem title<input value={form.title} onChange={(event) => updateField("title", event.target.value)} placeholder="e.g. Reduce manual hospital reporting" required minLength={8} /></label><div className="problem-form__grid"><label>Industry<input value={form.industry} onChange={(event) => updateField("industry", event.target.value)} placeholder="Healthcare" required /></label><label>Location<input value={form.location} onChange={(event) => updateField("location", event.target.value)} placeholder="Kolkata" required /></label><label>Work mode<select value={form.workMode} onChange={(event) => updateField("workMode", event.target.value as ProblemInput["workMode"])}><option>Remote</option><option>Hybrid</option><option>On site</option></select></label><label>Minimum budget (₹)<input type="number" min="0" step="1000" value={form.budgetMin} onChange={(event) => updateField("budgetMin", Number(event.target.value))} required /></label><label>Maximum budget (₹)<input type="number" min="0" step="1000" value={form.budgetMax} onChange={(event) => updateField("budgetMax", Number(event.target.value))} required /></label></div><label>Current process<textarea value={form.currentProcess} onChange={(event) => updateField("currentProcess", event.target.value)} placeholder="What happens today? Name the tools, handoffs, delays, and constraints." required minLength={20} /></label><label>Expected outcome<textarea value={form.expectedOutcome} onChange={(event) => updateField("expectedOutcome", event.target.value)} placeholder="What needs to be measurably better after this work is done?" required minLength={20} /></label><div className="problem-form__footer"><p><CheckCircle2 size={15} /> Your brief becomes visible to FDEs immediately. Admin can moderate it afterward.</p><button className="button button--dark" type="submit" disabled={isSaving}>{isSaving ? "Submitting…" : "Publish problem"} <Send size={16} /></button></div></form></section>}
    <section className="workspace__section"><div className="workspace__section-head"><div><span className="eyebrow"><span />My problem briefs</span><h2>What you have put in motion.</h2></div><span className="workspace__count">{problems.length.toString().padStart(2, "0")} submitted</span></div>{problems.length === 0 ? <div className="workspace-empty"><BriefcaseBusiness size={27} /><h3>Your problem desk is clear.</h3><p>Post a specific operational problem, and it will move into administrator review before becoming visible to Forward Deployed Engineers.</p><button className="text-link" type="button" onClick={() => setIsComposerOpen(true)}>Write a problem <Plus size={15} /></button></div> : <div className="workspace-problems">{problems.map((problem) => <article className="workspace-problem" key={problem.id}><div className="workspace-problem__top"><span>{problem.industry}</span><span className="status-pill">{problem.status}</span></div><h3>{problem.title}</h3><p>{problem.expectedOutcome}</p><div><span><MapPin size={14} /> {problem.location} · {problem.workMode}</span><strong>{formatBudget(problem)}</strong></div><small>Submitted {formatPostedDate(problem)}</small></article>)}</div>}</section>
  </WorkspaceShell>;
}

export default function BusinessDashboard() {
  return <AccessGate requiredRole="BUSINESS"><BusinessWorkspace /></AccessGate>;
}
